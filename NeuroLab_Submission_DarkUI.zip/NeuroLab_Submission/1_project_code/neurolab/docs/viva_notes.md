# Viva preparation - both members must be able to answer all of these

## Model lead (Member A) - be ready to explain every line of `neurolab/`
- Derive `dW`, `db`, `dx` of a Dense layer on the board. Why is there no `1/N` in `Dense.backward`? (The loss already averages.)
- Why do we subtract the max inside softmax? What is the Jacobian of softmax and why does `backward` avoid building it?
- Why He init for ReLU and Xavier for tanh/sigmoid? What happens with all-zero init?
- What does the gradient check compute, why central differences, and why can ReLU fail it near 0?
- Walk through Adam: first moment, second moment, bias correction. What happens on step 1?
- Why are the scalers fitted on the training split only? What would leak otherwise?
- Why is the test set evaluated once? Which split chose the best epoch?
- Why do NumPy and PyTorch curves match almost exactly when initial weights and batch order are shared?

## Application lead (Member B) - be ready to explain `app/`
- Trace one click on **Train** from the browser to the NumPy loop and back (NDJSON streaming, `fetch` + `ReadableStream`).
- Why do the two side-by-side runs use `net.clone()` and the same seed?
- What validation does `/api/predict` do and why? Where are predictions logged?
- How is the app deployed (Docker, port 7860)? What happens if `models/energy_numpy.npz` is missing?
- What happens when a learning rate makes the loss diverge?

## Both
- Explain the convergence table in your own words and say which result surprised you.
- Explain why Rosenbrock's valley is hard for plain SGD.
