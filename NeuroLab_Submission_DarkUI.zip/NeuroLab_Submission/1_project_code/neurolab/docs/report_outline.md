# Report outline (co-written by both members)

Fill each section with YOUR numbers from `results/`. Placeholders in [brackets].

1. **Introduction** - why open the `model.fit()` black box; goals; team roles (Member A model lead, Member B application lead).
2. **Neuron and network theory** - biological vs artificial neuron (reuse the diagram from `/neurons`), forward pass `y = f(xW + b)`, activations and their derivatives, loss functions, chain rule / backpropagation derivation for one Dense layer.
3. **Implementation** - package layout (`neurolab/`), each class, shapes, initialisation (He vs Xavier), why softmax backward uses `y * (dy - sum(dy*y))`.
4. **Verification** - gradient check table (`results/gradient_check.json`), worst relative error [ ], unit tests.
5. **Energy Efficiency experiment** - dataset description, 70/15/15 split with seed 42, scaling fitted on train only, architecture, training setup, NumPy vs PyTorch table (`results/energy_results.json`), plots (`results/energy_*.png`). State the heating-load test R2 [ ] against the 0.95 target.
6. **Optimizer study** - Rosenbrock/Beale paths (`results/optimizer_paths_*.png`, `optimizer_paths_summary.json`) and the convergence table (`results/convergence_comparison.md`). Write your OWN interpretation; do not copy the generic text.
7. **Web application** - architecture (browser -> FastAPI -> NumPy model), endpoints, streaming protocol, prediction logging, deployment URL / demo video link.
8. **Limitations and future work** - small dataset (768 rows), no test-time uncertainty, only MLPs, no regularisation experiments, etc.
9. **Individual contributions** - who wrote what; link to commit history.
10. **References** - Tsanas & Xifara (2012) for the dataset; Kingma & Ba (2015) for Adam; Tieleman & Hinton (2012) for RMSprop.
