"""Dense (fully connected) layer with hand-written forward/backward."""
from __future__ import annotations

import numpy as np


class Dense:
    """y = x @ W + b

    Shapes: x (N, in), W (in, out), b (1, out), y (N, out).

    Backward (chain rule), given g = dLoss/dy:
        dW = x^T @ g          (in, out)
        db = sum_rows(g)      (1, out)
        dx = g @ W^T          (N, in)
    The loss already averages over the batch, so no extra 1/N appears here.
    """

    def __init__(self, n_in: int, n_out: int, rng: np.random.Generator, init: str = "he"):
        if init == "he":  # good for ReLU-like units
            scale = np.sqrt(2.0 / n_in)
        elif init == "xavier":  # good for tanh / sigmoid / linear
            scale = np.sqrt(1.0 / n_in)
        else:
            raise ValueError("init must be 'he' or 'xavier'")
        self.W = rng.normal(0.0, scale, size=(n_in, n_out))
        self.b = np.zeros((1, n_out))
        self.dW = np.zeros_like(self.W)
        self.db = np.zeros_like(self.b)
        self._x = None

    def forward(self, x: np.ndarray) -> np.ndarray:
        self._x = x
        return x @ self.W + self.b

    def backward(self, grad_out: np.ndarray) -> np.ndarray:
        self.dW = self._x.T @ grad_out
        self.db = np.sum(grad_out, axis=0, keepdims=True)
        return grad_out @ self.W.T

    @property
    def params(self):
        return [self.W, self.b]

    @property
    def grads(self):
        return [self.dW, self.db]

    def __repr__(self):
        return f"Dense({self.W.shape[0]} -> {self.W.shape[1]})"
