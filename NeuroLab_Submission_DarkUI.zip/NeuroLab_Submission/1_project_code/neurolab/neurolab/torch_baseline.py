"""The same network rebuilt with PyTorch (framework component of the project).

Two variants are trained so the comparison is honest:

* ``same_init=True``  : copies the NumPy network's initial weights and replays the
  exact same mini-batch order.  With float64 and identical Adam settings the two
  training curves should be almost indistinguishable - that is strong evidence
  the hand-written backprop and optimizers are correct.
* ``same_init=False`` : PyTorch's own default initialisation, i.e. what a student
  gets from ``nn.Linear`` without thinking.  Test error should still be similar.
"""
from __future__ import annotations

import numpy as np

from .data import EnergySplit
from .energy import regression_metrics  # noqa: F401  (kept for symmetry / re-export)
from .network import Network, iterate_minibatches, r2_score


def _torch():
    try:
        import torch
        return torch
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("PyTorch is not installed. Run: pip install torch") from exc


_ACTS = {"relu": "ReLU", "tanh": "Tanh", "sigmoid": "Sigmoid", "leaky_relu": "LeakyReLU"}


def build_torch_mlp(in_dim, hidden, out_dim, activation):
    torch = _torch()
    nn = torch.nn
    layers, prev = [], in_dim
    for h in hidden:
        layers += [nn.Linear(prev, h), getattr(nn, _ACTS[activation])()]
        prev = h
    layers.append(nn.Linear(prev, out_dim))
    return nn.Sequential(*layers).double()


def copy_numpy_weights(numpy_net: Network, torch_net) -> None:
    torch = _torch()
    linears = [m for m in torch_net if isinstance(m, torch.nn.Linear)]
    with torch.no_grad():
        for lin, dense in zip(linears, numpy_net.dense_layers):
            lin.weight.copy_(torch.from_numpy(dense.W.T.copy()))  # torch stores (out, in)
            lin.bias.copy_(torch.from_numpy(dense.b.reshape(-1).copy()))


def train_torch(split: EnergySplit, hidden, activation, lr, epochs, batch_size, seed,
                numpy_init: Network | None = None, same_init: bool = True, verbose: bool = False) -> dict:
    torch = _torch()
    torch.manual_seed(seed)
    net = build_torch_mlp(split.Xtr.shape[1], hidden, split.Ytr.shape[1], activation)
    if same_init:
        if numpy_init is None:
            raise ValueError("numpy_init is required when same_init=True")
        copy_numpy_weights(numpy_init, net)
    opt = torch.optim.Adam(net.parameters(), lr=lr, betas=(0.9, 0.999), eps=1e-8)
    loss_fn = torch.nn.MSELoss()
    t = lambda a: torch.from_numpy(np.ascontiguousarray(a)).double()
    Xtr, Ytr, Xva, Yva = t(split.Xtr), t(split.Ytr), t(split.Xva), t(split.Yva)
    rng = np.random.default_rng(seed)  # same permutation stream as neurolab.network.fit_iter
    history = {"train_loss": [], "val_loss": []}

    def snapshot():
        with torch.no_grad():
            history["train_loss"].append(float(loss_fn(net(Xtr), Ytr)))
            history["val_loss"].append(float(loss_fn(net(Xva), Yva)))

    snapshot()
    best_val, best_state, best_epoch = history["val_loss"][0], {k: v.clone() for k, v in net.state_dict().items()}, 0
    for epoch in range(1, epochs + 1):
        for idx in iterate_minibatches(len(Xtr), batch_size, rng):
            i = torch.from_numpy(idx)
            opt.zero_grad()
            loss_fn(net(Xtr[i]), Ytr[i]).backward()
            opt.step()
        snapshot()
        if history["val_loss"][-1] < best_val:
            best_val, best_epoch = history["val_loss"][-1], epoch
            best_state = {k: v.clone() for k, v in net.state_dict().items()}
        if verbose and epoch % 50 == 0:
            print(f"  [torch] epoch {epoch:4d} val {history['val_loss'][-1]:.5f}")
    net.load_state_dict(best_state)

    with torch.no_grad():
        pred = net(t(split.Xte)).numpy()
    true = split.y_scaler.inverse(split.Yte)
    pred = split.y_scaler.inverse(pred)
    r2 = r2_score(true, pred)
    rmse = np.sqrt(np.mean((true - pred) ** 2, axis=0))
    return {"history": history, "best_epoch": best_epoch,
            "test_metrics": {"Heating load": {"r2": float(r2[0]), "rmse": float(rmse[0])},
                             "Cooling load": {"r2": float(r2[1]), "rmse": float(rmse[1])}}}
