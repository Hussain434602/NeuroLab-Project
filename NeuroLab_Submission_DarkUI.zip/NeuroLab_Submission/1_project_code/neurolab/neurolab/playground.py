"""Engine behind the web playground.

``playground_stream(config)`` is a plain Python generator of JSON-serialisable
dicts, so it can be tested without any web framework.  The API layer just wraps
it in a streaming response.

Message types:
    {"type": "init", ...}     once: dataset points / axis info
    {"type": "epoch", ...}    one per run per epoch (viz attached every ``viz_every`` epochs)
    {"type": "done"}
"""
from __future__ import annotations

import math
import time
from typing import Iterator

import numpy as np

from .activations import HIDDEN_ACTIVATIONS
from .data import TARGET_NAMES, load_energy, make_classification_data, split_energy
from .network import build_mlp, fit_iter, r2_score
from .optimizers import OPTIMIZERS, make_optimizer

DATASETS = ("moons", "circles", "spiral", "energy")
GRID = 30
MAX_EPOCHS, MAX_LAYERS, MAX_NEURONS = 500, 6, 64

_energy_cache: dict = {}


def validate_config(cfg: dict) -> dict:
    """Clamp / check user input. Raises ValueError with a readable message."""
    out = {}
    out["dataset"] = cfg.get("dataset", "moons")
    if out["dataset"] not in DATASETS:
        raise ValueError(f"dataset must be one of {DATASETS}")
    hidden = cfg.get("hidden", [8, 8])
    if not isinstance(hidden, (list, tuple)) or not (1 <= len(hidden) <= MAX_LAYERS):
        raise ValueError(f"hidden must be a list of 1 to {MAX_LAYERS} layer sizes")
    out["hidden"] = [max(1, min(MAX_NEURONS, int(h))) for h in hidden]
    out["activation"] = cfg.get("activation", "tanh")
    if out["activation"] not in HIDDEN_ACTIVATIONS:
        raise ValueError(f"activation must be one of {HIDDEN_ACTIVATIONS}")
    runs = cfg.get("optimizers") or [{"name": "adam", "lr": 0.01}]
    if not (1 <= len(runs) <= 2):
        raise ValueError("choose one or two optimizers")
    out["optimizers"] = []
    for r in runs:
        name, lr = r.get("name", "adam"), float(r.get("lr", 0.01))
        if name not in OPTIMIZERS:
            raise ValueError(f"optimizer must be one of {sorted(OPTIMIZERS)}")
        if not (1e-6 <= lr <= 10):
            raise ValueError("learning rate must be between 1e-6 and 10")
        out["optimizers"].append({"name": name, "lr": lr})
    out["epochs"] = max(1, min(MAX_EPOCHS, int(cfg.get("epochs", 100))))
    out["batch_size"] = max(1, min(512, int(cfg.get("batch_size", 32))))
    out["seed"] = int(cfg.get("seed", 0))
    out["noise"] = max(0.0, min(0.5, float(cfg.get("noise", 0.15))))
    out["viz_every"] = max(1, min(50, int(cfg.get("viz_every", 5))))
    out["delay_ms"] = max(0, min(200, int(cfg.get("delay_ms", 15))))
    return out


def _round(a, nd=3):
    return np.round(np.asarray(a, dtype=float), nd).tolist()


def _get_energy_split(seed: int):
    if seed not in _energy_cache:
        data = load_energy()
        _energy_cache[seed] = split_energy(data, seed=seed)
    return _energy_cache[seed]


def playground_stream(raw_cfg: dict) -> Iterator[dict]:
    cfg = validate_config(raw_cfg)
    is_energy = cfg["dataset"] == "energy"

    if is_energy:
        sp = _get_energy_split(cfg["seed"])
        Xtr, Ytr, Xva, Yva = sp.Xtr, sp.Ytr, sp.Xva, sp.Yva
        task, out_dim = "regression", 2
        init = {"type": "init", "task": task, "target": TARGET_NAMES[0],
                "synthetic": sp.source.startswith("SYNTHETIC"), "n_train": len(Xtr), "n_val": len(Xva)}
    else:
        Xtr, Ytr, Xva, Yva = make_classification_data(cfg["dataset"], noise=cfg["noise"], seed=cfg["seed"])
        task, out_dim = "classification", 2
        pad = 0.4
        lo, hi = np.vstack([Xtr, Xva]).min(axis=0) - pad, np.vstack([Xtr, Xva]).max(axis=0) + pad
        gx, gy = np.meshgrid(np.linspace(lo[0], hi[0], GRID), np.linspace(lo[1], hi[1], GRID))
        grid = np.column_stack([gx.ravel(), gy.ravel()])
        init = {"type": "init", "task": task, "grid": GRID, "bounds": [lo[0], hi[0], lo[1], hi[1]],
                "train": {"x": _round(Xtr), "y": Ytr.tolist()}, "val": {"x": _round(Xva), "y": Yva.tolist()}}
    init["runs"] = [f"{o['name']} (lr {o['lr']:g})" for o in cfg["optimizers"]]
    yield init

    # Same architecture, same initial weights, same batch order for every run.
    base = build_mlp(Xtr.shape[1], cfg["hidden"], out_dim, cfg["activation"], task, seed=cfg["seed"])
    runs = []
    for spec in cfg["optimizers"]:
        net = base.clone()
        opt = make_optimizer(spec["name"], spec["lr"])
        gen = fit_iter(net, opt, Xtr, Ytr, Xva, Yva, cfg["epochs"], cfg["batch_size"], cfg["seed"])
        runs.append({"net": net, "gen": gen, "alive": True})

    for _ in range(cfg["epochs"] + 1):
        for i, run in enumerate(runs):
            if not run["alive"]:
                continue
            try:
                rec = next(run["gen"])
            except StopIteration:
                run["alive"] = False
                continue
            net = run["net"]
            finite = math.isfinite(rec["train_loss"]) and math.isfinite(rec["val_loss"])
            msg = {"type": "epoch", "run": i, "epoch": rec["epoch"],
                   "train_loss": rec["train_loss"] if finite else None,
                   "val_loss": rec["val_loss"] if finite else None, "diverged": not finite}
            if finite:
                pred = net.predict(Xva)
                if task == "classification":
                    msg["val_metric"] = {"name": "accuracy", "value": float(np.mean(pred.argmax(axis=1) == Yva))}
                else:
                    msg["val_metric"] = {"name": "R2 heating", "value": float(r2_score(Yva, pred)[0])}
                show = rec["epoch"] % cfg["viz_every"] == 0 or rec["epoch"] in (0, cfg["epochs"])
                if show:
                    if task == "classification":
                        msg["viz"] = {"p1": _round(net.predict(grid)[:, 1])}
                    else:
                        yt = sp.y_scaler.inverse(Yva)[:, 0]
                        yp = sp.y_scaler.inverse(pred)[:, 0]
                        msg["viz"] = {"actual": _round(yt, 2), "pred": _round(yp, 2)}
            else:
                run["alive"] = False
            yield msg
        if cfg["delay_ms"]:
            time.sleep(cfg["delay_ms"] / 1000.0)
        if not any(r["alive"] for r in runs):
            break
    yield {"type": "done"}
