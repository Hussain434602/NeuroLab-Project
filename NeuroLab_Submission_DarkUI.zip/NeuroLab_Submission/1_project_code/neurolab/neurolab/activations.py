"""Activation functions with hand-written forward and backward passes.

Every activation follows the same tiny contract:

    y = act.forward(x)      # caches whatever backward needs
    dx = act.backward(dy)   # dy is dLoss/dy, returns dLoss/dx

No autograd is used anywhere in this package; every derivative below is
derived by hand and verified numerically in ``neurolab.gradcheck``.
"""
from __future__ import annotations

import numpy as np


class Activation:
    name = "activation"

    def forward(self, x: np.ndarray) -> np.ndarray:  # pragma: no cover - interface
        raise NotImplementedError

    def backward(self, grad_out: np.ndarray) -> np.ndarray:  # pragma: no cover
        raise NotImplementedError

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"


class Identity(Activation):
    """f(x) = x. Used on the output layer of a regressor."""

    name = "identity"

    def forward(self, x):
        return x

    def backward(self, grad_out):
        return grad_out


class Sigmoid(Activation):
    """f(x) = 1 / (1 + e^-x),  f'(x) = f(x) (1 - f(x))."""

    name = "sigmoid"

    def forward(self, x):
        # 0.5 * (1 + tanh(x / 2)) is the same function but never overflows.
        self.y = 0.5 * (1.0 + np.tanh(0.5 * x))
        return self.y

    def backward(self, grad_out):
        return grad_out * self.y * (1.0 - self.y)


class Tanh(Activation):
    """f(x) = tanh(x),  f'(x) = 1 - f(x)^2."""

    name = "tanh"

    def forward(self, x):
        self.y = np.tanh(x)
        return self.y

    def backward(self, grad_out):
        return grad_out * (1.0 - self.y ** 2)


class ReLU(Activation):
    """f(x) = max(0, x),  f'(x) = 1 if x > 0 else 0."""

    name = "relu"

    def forward(self, x):
        self.mask = x > 0
        return x * self.mask

    def backward(self, grad_out):
        return grad_out * self.mask


class LeakyReLU(Activation):
    """f(x) = x if x > 0 else alpha * x."""

    name = "leaky_relu"

    def __init__(self, alpha: float = 0.01):
        self.alpha = alpha

    def forward(self, x):
        self.mask = x > 0
        return np.where(self.mask, x, self.alpha * x)

    def backward(self, grad_out):
        return grad_out * np.where(self.mask, 1.0, self.alpha)

    def __repr__(self):
        return f"LeakyReLU(alpha={self.alpha})"


class Softmax(Activation):
    """Row-wise softmax.

    Forward:  y_i = exp(x_i - max x) / sum_j exp(x_j - max x)
    Backward: the Jacobian is diag(y) - y y^T, so the vector-Jacobian product is
              dx = y * (dy - sum(dy * y))     (per row)
    """

    name = "softmax"

    def forward(self, x):
        shifted = x - np.max(x, axis=1, keepdims=True)
        e = np.exp(shifted)
        self.y = e / np.sum(e, axis=1, keepdims=True)
        return self.y

    def backward(self, grad_out):
        dot = np.sum(grad_out * self.y, axis=1, keepdims=True)
        return self.y * (grad_out - dot)


ACTIVATIONS = {
    "identity": Identity,
    "sigmoid": Sigmoid,
    "tanh": Tanh,
    "relu": ReLU,
    "leaky_relu": LeakyReLU,
    "softmax": Softmax,
}

HIDDEN_ACTIVATIONS = ("sigmoid", "tanh", "relu", "leaky_relu")


def get_activation(name: str) -> Activation:
    try:
        return ACTIVATIONS[name]()
    except KeyError:
        raise ValueError(f"Unknown activation '{name}'. Choose from {sorted(ACTIVATIONS)}")
