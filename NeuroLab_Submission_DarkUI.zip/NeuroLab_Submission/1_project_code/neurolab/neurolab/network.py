"""A tiny sequential network: layers + a loss, with manual backprop."""
from __future__ import annotations

import copy
from typing import Iterator, Sequence

import numpy as np

from .activations import Softmax, Identity, get_activation
from .layers import Dense
from .losses import CrossEntropy, MSE
from .optimizers import Optimizer


class Network:
    def __init__(self, layers: list, loss):
        self.layers = layers
        self.loss = loss

    # ------------------------------------------------------------------ passes
    def forward(self, x: np.ndarray) -> np.ndarray:
        for layer in self.layers:
            x = layer.forward(x)
        return x

    def backward(self) -> None:
        grad = self.loss.backward()
        for layer in reversed(self.layers):
            grad = layer.backward(grad)

    def loss_and_grad(self, x: np.ndarray, y: np.ndarray) -> float:
        """Forward + loss + backward. Gradients end up in each Dense layer."""
        out = self.forward(x)
        value = self.loss.forward(out, y)
        self.backward()
        return value

    def evaluate_loss(self, x: np.ndarray, y: np.ndarray) -> float:
        return self.loss.forward(self.forward(x), y)

    def predict(self, x: np.ndarray) -> np.ndarray:
        return self.forward(x)

    # -------------------------------------------------------------- parameters
    @property
    def dense_layers(self) -> list[Dense]:
        return [l for l in self.layers if isinstance(l, Dense)]

    def params(self) -> list[np.ndarray]:
        return [p for l in self.dense_layers for p in l.params]

    def grads(self) -> list[np.ndarray]:
        return [g for l in self.dense_layers for g in l.grads]

    def get_weights(self) -> list[np.ndarray]:
        return [p.copy() for p in self.params()]

    def set_weights(self, weights: Sequence[np.ndarray]) -> None:
        for p, w in zip(self.params(), weights):
            p[...] = w

    def clone(self) -> "Network":
        """Deep copy with identical weights (used for side-by-side runs)."""
        return copy.deepcopy(self)

    def summary(self) -> str:
        n = sum(p.size for p in self.params())
        return " -> ".join(repr(l) for l in self.layers) + f"   [{n} parameters]"


def build_mlp(
    in_dim: int,
    hidden: Sequence[int],
    out_dim: int,
    activation: str = "relu",
    task: str = "regression",
    seed: int = 0,
) -> Network:
    """Build an MLP.  regression -> Identity output + MSE; classification -> Softmax + CE."""
    if task not in ("regression", "classification"):
        raise ValueError("task must be 'regression' or 'classification'")
    rng = np.random.default_rng(seed)
    init = "he" if activation in ("relu", "leaky_relu") else "xavier"
    layers: list = []
    prev = in_dim
    for h in hidden:
        layers.append(Dense(prev, int(h), rng, init))
        layers.append(get_activation(activation))
        prev = int(h)
    layers.append(Dense(prev, out_dim, rng, "xavier"))
    if task == "classification":
        layers.append(Softmax())
        loss = CrossEntropy()
    else:
        layers.append(Identity())
        loss = MSE()
    return Network(layers, loss)


def iterate_minibatches(n: int, batch_size: int, rng: np.random.Generator) -> Iterator[np.ndarray]:
    order = rng.permutation(n)
    for start in range(0, n, batch_size):
        yield order[start:start + batch_size]


def fit_iter(
    net: Network,
    optimizer: Optimizer,
    x_train, y_train, x_val, y_val,
    epochs: int,
    batch_size: int,
    seed: int = 0,
) -> Iterator[dict]:
    """Train and yield one dict per epoch (epoch 0 = before any update).

    The batch order depends only on ``seed``, so two runs with the same seed see
    identical mini-batches; combined with ``net.clone()`` this gives a fair
    optimizer-vs-optimizer comparison from the same initial weights.
    """
    rng = np.random.default_rng(seed)
    n = len(x_train)
    yield {"epoch": 0, "train_loss": net.evaluate_loss(x_train, y_train),
           "val_loss": net.evaluate_loss(x_val, y_val)}
    for epoch in range(1, epochs + 1):
        for idx in iterate_minibatches(n, batch_size, rng):
            net.loss_and_grad(x_train[idx], y_train[idx])
            optimizer.step(net.params(), net.grads())
        yield {"epoch": epoch, "train_loss": net.evaluate_loss(x_train, y_train),
               "val_loss": net.evaluate_loss(x_val, y_val)}


def r2_score(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    """Per-output coefficient of determination."""
    y_true = np.atleast_2d(y_true.T).T if y_true.ndim == 1 else y_true
    y_pred = np.atleast_2d(y_pred.T).T if y_pred.ndim == 1 else y_pred
    ss_res = np.sum((y_true - y_pred) ** 2, axis=0)
    ss_tot = np.sum((y_true - y_true.mean(axis=0)) ** 2, axis=0)
    return 1.0 - ss_res / np.maximum(ss_tot, 1e-12)
