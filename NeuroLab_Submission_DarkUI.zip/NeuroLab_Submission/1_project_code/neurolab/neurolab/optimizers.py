"""Optimizers written by hand.  They update NumPy arrays *in place*.

    opt.step(params, grads)   # both are lists of arrays with matching shapes

All four work for network weights and for the 2-D test surfaces alike.
"""
from __future__ import annotations

import numpy as np


class Optimizer:
    name = "optimizer"

    def __init__(self, lr: float):
        self.lr = lr

    def step(self, params, grads):  # pragma: no cover - interface
        raise NotImplementedError

    def __repr__(self):
        return f"{self.__class__.__name__}(lr={self.lr})"


class SGD(Optimizer):
    """theta <- theta - lr * g"""

    name = "sgd"

    def step(self, params, grads):
        for p, g in zip(params, grads):
            p -= self.lr * g


class Momentum(Optimizer):
    """v <- mu v - lr g ;  theta <- theta + v   (classical / heavy-ball momentum)"""

    name = "momentum"

    def __init__(self, lr: float, momentum: float = 0.9):
        super().__init__(lr)
        self.mu = momentum
        self._v = None

    def step(self, params, grads):
        if self._v is None:
            self._v = [np.zeros_like(p) for p in params]
        for p, g, v in zip(params, grads, self._v):
            v *= self.mu
            v -= self.lr * g
            p += v


class RMSprop(Optimizer):
    """cache <- rho cache + (1-rho) g^2 ;  theta <- theta - lr g / (sqrt(cache) + eps)"""

    name = "rmsprop"

    def __init__(self, lr: float, rho: float = 0.9, eps: float = 1e-8):
        super().__init__(lr)
        self.rho, self.eps = rho, eps
        self._cache = None

    def step(self, params, grads):
        if self._cache is None:
            self._cache = [np.zeros_like(p) for p in params]
        for p, g, c in zip(params, grads, self._cache):
            c *= self.rho
            c += (1.0 - self.rho) * g * g
            p -= self.lr * g / (np.sqrt(c) + self.eps)


class Adam(Optimizer):
    """m <- b1 m + (1-b1) g ; v <- b2 v + (1-b2) g^2 ; bias-corrected update."""

    name = "adam"

    def __init__(self, lr: float, beta1: float = 0.9, beta2: float = 0.999, eps: float = 1e-8):
        super().__init__(lr)
        self.b1, self.b2, self.eps = beta1, beta2, eps
        self._m = self._v = None
        self.t = 0

    def step(self, params, grads):
        if self._m is None:
            self._m = [np.zeros_like(p) for p in params]
            self._v = [np.zeros_like(p) for p in params]
        self.t += 1
        c1 = 1.0 - self.b1 ** self.t
        c2 = 1.0 - self.b2 ** self.t
        for p, g, m, v in zip(params, grads, self._m, self._v):
            m *= self.b1
            m += (1.0 - self.b1) * g
            v *= self.b2
            v += (1.0 - self.b2) * g * g
            p -= self.lr * (m / c1) / (np.sqrt(v / c2) + self.eps)


OPTIMIZERS = {"sgd": SGD, "momentum": Momentum, "rmsprop": RMSprop, "adam": Adam}


def make_optimizer(name: str, lr: float) -> Optimizer:
    try:
        return OPTIMIZERS[name](lr)
    except KeyError:
        raise ValueError(f"Unknown optimizer '{name}'. Choose from {sorted(OPTIMIZERS)}")
