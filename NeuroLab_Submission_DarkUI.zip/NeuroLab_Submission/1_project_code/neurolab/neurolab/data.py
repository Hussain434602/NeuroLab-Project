"""Datasets for NeuroLab.

* UCI Energy Efficiency (id=242): 768 buildings, 8 features, 2 targets.
* moons / circles / spiral: generated in code, no download.

Loading order for Energy Efficiency (first that works wins):
    1. a local file  data/ENB2012_data.xlsx  or  data/ENB2012_data.csv
    2. ``ucimlrepo.fetch_ucirepo(id=242)``
    3. a clearly-labelled SYNTHETIC stand-in (only so the code and UI can be
       tested offline; never report metrics computed on it).
"""
from __future__ import annotations

import os
import warnings
from dataclasses import dataclass
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"

FEATURE_NAMES = [
    "Relative compactness", "Surface area", "Wall area", "Roof area",
    "Overall height", "Orientation", "Glazing area", "Glazing area distribution",
]
TARGET_NAMES = ["Heating load", "Cooling load"]
FEATURE_RANGES = [(0.62, 0.98), (514.5, 808.5), (245.0, 416.5), (110.25, 220.5),
                  (3.5, 7.0), (2, 5), (0.0, 0.4), (0, 5)]

# The 12 building forms of the original study: (RC, surface, wall, roof, height)
_FORMS = [
    (0.98, 514.5, 294.0, 110.25, 7.0), (0.90, 563.5, 318.5, 122.5, 7.0),
    (0.86, 588.0, 294.0, 147.0, 7.0), (0.82, 612.5, 318.5, 147.0, 7.0),
    (0.79, 637.0, 343.0, 147.0, 7.0), (0.76, 661.5, 416.5, 122.5, 7.0),
    (0.74, 686.0, 245.0, 220.5, 3.5), (0.71, 710.5, 269.5, 220.5, 3.5),
    (0.69, 735.0, 294.0, 220.5, 3.5), (0.66, 759.5, 318.5, 220.5, 3.5),
    (0.64, 784.0, 343.0, 220.5, 3.5), (0.62, 808.5, 367.5, 220.5, 3.5),
]


@dataclass
class EnergyData:
    X: np.ndarray          # (768, 8)
    Y: np.ndarray          # (768, 2)
    source: str            # "local-file" | "ucimlrepo" | "SYNTHETIC-FALLBACK"

    @property
    def is_synthetic(self) -> bool:
        return self.source.startswith("SYNTHETIC")


def _from_frame(df) -> tuple[np.ndarray, np.ndarray]:
    df = df.rename(columns=lambda c: str(c).strip())
    xs = [f"X{i}" for i in range(1, 9)]
    ys = ["Y1", "Y2"]
    df = df[xs + ys].dropna()
    return df[xs].to_numpy(dtype=float), df[ys].to_numpy(dtype=float)


def _synthetic_energy(seed: int = 0) -> EnergyData:
    """Rebuild the 768-design grid (12 forms x 4 orientations x 16 glazing setups)
    with made-up smooth targets.  FOR PLUMBING TESTS ONLY."""
    rng = np.random.default_rng(seed)
    glazing = [(0.0, 0)] + [(g, d) for g in (0.1, 0.25, 0.4) for d in range(1, 6)]
    rows = [(*form, ori, g, d) for form in _FORMS for ori in (2, 3, 4, 5) for g, d in glazing]
    X = np.array(rows, dtype=float)
    rc, sa, wall, roof, h, ori, g, d = X.T
    heat = (-60 + 90 * rc + 5.5 * h - 0.02 * roof + 28 * g + 0.4 * d + 0.3 * (ori == 3)
            + 0.02 * wall + rng.normal(0, 0.8, len(X)))
    cool = (-25 + 55 * rc + 3.5 * h - 0.01 * roof + 15 * g + 0.2 * d + rng.normal(0, 1.0, len(X)))
    return EnergyData(X, np.column_stack([heat, cool]), "SYNTHETIC-FALLBACK")


def load_energy(allow_synthetic: bool = True) -> EnergyData:
    import pandas as pd

    for name, reader in (("ENB2012_data.xlsx", pd.read_excel), ("ENB2012_data.csv", pd.read_csv)):
        path = DATA_DIR / name
        if path.exists():
            X, Y = _from_frame(reader(path))
            return EnergyData(X, Y, "local-file")
    try:
        from ucimlrepo import fetch_ucirepo

        ds = fetch_ucirepo(id=242)
        X, Y = _from_frame(pd.concat([ds.data.features, ds.data.targets], axis=1))
        return EnergyData(X, Y, "ucimlrepo")
    except Exception as exc:  # no internet / package missing
        if not allow_synthetic or os.environ.get("NEUROLAB_NO_SYNTHETIC"):
            raise RuntimeError(
                "Could not load the Energy Efficiency dataset. Install ucimlrepo and connect to the "
                "internet, or download ENB2012_data.xlsx from "
                "https://archive.ics.uci.edu/dataset/242/energy+efficiency into the data/ folder."
            ) from exc
        warnings.warn(
            "\n" + "!" * 70 + "\nUSING SYNTHETIC STAND-IN FOR ENERGY EFFICIENCY (" + repr(exc)[:60]
            + ").\nDo NOT report these numbers. Put ENB2012_data.xlsx in data/ or enable internet.\n"
            + "!" * 70, stacklevel=2)
        return _synthetic_energy()


@dataclass
class Standardizer:
    mean: np.ndarray
    std: np.ndarray

    @classmethod
    def fit(cls, a: np.ndarray) -> "Standardizer":
        std = a.std(axis=0)
        return cls(a.mean(axis=0), np.where(std < 1e-12, 1.0, std))

    def transform(self, a): return (a - self.mean) / self.std
    def inverse(self, a): return a * self.std + self.mean


@dataclass
class EnergySplit:
    Xtr: np.ndarray; Ytr: np.ndarray
    Xva: np.ndarray; Yva: np.ndarray
    Xte: np.ndarray; Yte: np.ndarray
    x_scaler: Standardizer
    y_scaler: Standardizer
    source: str


def split_energy(data: EnergyData, seed: int = 42, val_frac: float = 0.15, test_frac: float = 0.15) -> EnergySplit:
    """Fixed-seed train/val/test split. Scalers are fitted on the training part only."""
    n = len(data.X)
    order = np.random.default_rng(seed).permutation(n)
    n_te, n_va = int(round(n * test_frac)), int(round(n * val_frac))
    te, va, tr = order[:n_te], order[n_te:n_te + n_va], order[n_te + n_va:]
    xs, ys = Standardizer.fit(data.X[tr]), Standardizer.fit(data.Y[tr])
    f = lambda idx: (xs.transform(data.X[idx]), ys.transform(data.Y[idx]))
    (Xtr, Ytr), (Xva, Yva), (Xte, Yte) = f(tr), f(va), f(te)
    return EnergySplit(Xtr, Ytr, Xva, Yva, Xte, Yte, xs, ys, data.source)


# --------------------------------------------------------------- 2-D classification
def make_spirals(n: int, noise: float, rng: np.random.Generator, n_classes: int = 2):
    per = n // n_classes
    xs, ys = [], []
    for c in range(n_classes):
        r = np.linspace(0.05, 1.0, per)
        t = np.linspace(c * 2 * np.pi / n_classes, c * 2 * np.pi / n_classes + 3.2 * np.pi, per)
        t = t + rng.normal(0, noise * 2.0, per)
        xs.append(np.column_stack([r * np.sin(t), r * np.cos(t)]))
        ys.append(np.full(per, c))
    return np.vstack(xs), np.concatenate(ys)


def make_classification_data(name: str, n: int = 400, noise: float = 0.15, seed: int = 0, val_frac: float = 0.25):
    """Return standardized (Xtr, ytr, Xva, yva) for 'moons', 'circles' or 'spiral'."""
    from sklearn.datasets import make_circles, make_moons

    rng = np.random.default_rng(seed)
    if name == "moons":
        X, y = make_moons(n_samples=n, noise=noise, random_state=seed)
    elif name == "circles":
        X, y = make_circles(n_samples=n, noise=noise * 0.6, factor=0.5, random_state=seed)
    elif name == "spiral":
        X, y = make_spirals(n, noise * 0.5, rng)
    else:
        raise ValueError("dataset must be 'moons', 'circles' or 'spiral'")
    order = rng.permutation(len(X))
    X, y = X[order], y[order]
    n_va = int(len(X) * val_frac)
    Xtr, ytr, Xva, yva = X[n_va:], y[n_va:], X[:n_va], y[:n_va]
    sc = Standardizer.fit(Xtr)
    return sc.transform(Xtr), ytr.astype(int), sc.transform(Xva), yva.astype(int)
