"""Numerical gradient checking (central differences).

For a parameter theta_i we compare the analytic gradient from ``backward`` with

    (L(theta_i + h) - L(theta_i - h)) / (2 h)

and report the relative error  ||a - n|| / (||a|| + ||n||).  The project
requirement is that this is below 1e-5 for every layer.
"""
from __future__ import annotations

import numpy as np

from .activations import ACTIVATIONS, get_activation
from .losses import CrossEntropy, MSE
from .network import Network, build_mlp

THRESHOLD = 1e-5


def relative_error(analytic: np.ndarray, numeric: np.ndarray) -> float:
    num = np.linalg.norm(analytic - numeric)
    den = np.linalg.norm(analytic) + np.linalg.norm(numeric)
    return float(num / den) if den > 1e-15 else 0.0


def numerical_gradient(f, x: np.ndarray, h: float = 1e-6) -> np.ndarray:
    """Central-difference gradient of scalar function ``f`` w.r.t. array ``x`` (modified in place, then restored)."""
    grad = np.zeros_like(x)
    it = np.nditer(x, flags=["multi_index"], op_flags=["readwrite"])
    while not it.finished:
        idx = it.multi_index
        original = x[idx]
        x[idx] = original + h
        f_plus = f()
        x[idx] = original - h
        f_minus = f()
        x[idx] = original
        grad[idx] = (f_plus - f_minus) / (2.0 * h)
        it.iternext()
    return grad


def check_network(net: Network, x: np.ndarray, y: np.ndarray) -> list[dict]:
    """Check dW and db of every Dense layer of ``net``."""
    net.loss_and_grad(x, y)  # fills analytic gradients
    rows = []
    for i, layer in enumerate(net.dense_layers):
        for pname, param, grad in (("W", layer.W, layer.dW), ("b", layer.b, layer.db)):
            analytic = grad.copy()
            numeric = numerical_gradient(lambda: net.evaluate_loss(x, y), param)
            err = relative_error(analytic, numeric)
            rows.append({"layer": f"Dense {i + 1} ({layer.W.shape[0]}x{layer.W.shape[1]})",
                         "param": pname, "rel_error": err, "passed": err < THRESHOLD})
    return rows


def check_activation(name: str, rng: np.random.Generator, shape=(5, 4)) -> dict:
    """Check the input-gradient of a single activation against a random upstream gradient."""
    act = get_activation(name)
    x = rng.normal(size=shape)
    upstream = rng.normal(size=shape)

    def scalar():
        return float(np.sum(act.forward(x) * upstream))

    act.forward(x)
    analytic = act.backward(upstream)
    numeric = numerical_gradient(scalar, x)
    err = relative_error(analytic, numeric)
    return {"layer": f"Activation {name}", "param": "input", "rel_error": err, "passed": err < THRESHOLD}


def check_loss(name: str, rng: np.random.Generator) -> dict:
    if name == "mse":
        loss, pred, target = MSE(), rng.normal(size=(6, 3)), rng.normal(size=(6, 3))
    else:
        loss = CrossEntropy()
        logits = rng.normal(size=(6, 4))
        pred = np.exp(logits) / np.exp(logits).sum(axis=1, keepdims=True)
        target = rng.integers(0, 4, size=6)
    loss.forward(pred, target)
    analytic = loss.backward()
    numeric = numerical_gradient(lambda: loss.forward(pred, target), pred)
    err = relative_error(analytic, numeric)
    return {"layer": f"Loss {name}", "param": "prediction", "rel_error": err, "passed": err < THRESHOLD}


def run_full_check(seed: int = 0) -> list[dict]:
    """Every activation, both losses, and full networks (4 hidden activations x 2 tasks)."""
    rng = np.random.default_rng(seed)
    rows = [check_activation(n, rng) for n in ACTIVATIONS]
    rows += [check_loss("mse", rng), check_loss("cross_entropy", rng)]
    x = rng.normal(size=(8, 5))
    for act in ("sigmoid", "tanh", "relu", "leaky_relu"):
        net = build_mlp(5, [7, 6], 3, act, "regression", seed=seed)
        _to_float64(net)
        for r in check_network(net, x, rng.normal(size=(8, 3))):
            r["layer"] = f"[regression/{act}] " + r["layer"]
            rows.append(r)
    for act in ("tanh", "relu"):
        net = build_mlp(5, [7, 6], 3, act, "classification", seed=seed)
        _to_float64(net)
        for r in check_network(net, x, rng.integers(0, 3, size=8)):
            r["layer"] = f"[classification/{act}] " + r["layer"]
            rows.append(r)
    return rows


def _to_float64(net: Network) -> None:
    for layer in net.dense_layers:
        layer.W = layer.W.astype(np.float64)
        layer.b = layer.b.astype(np.float64)


if __name__ == "__main__":
    results = run_full_check()
    width = max(len(r["layer"]) for r in results)
    for r in results:
        print(f"{r['layer']:<{width}}  {r['param']:<10} rel.err = {r['rel_error']:.2e}  {'PASS' if r['passed'] else 'FAIL'}")
    worst = max(r["rel_error"] for r in results)
    print(f"\nworst relative error: {worst:.2e}  (threshold {THRESHOLD:.0e})")
    raise SystemExit(0 if all(r["passed"] for r in results) else 1)
