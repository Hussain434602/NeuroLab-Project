"""Train, save and load the multi-output Energy Efficiency regressor (NumPy)."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .data import EnergySplit, FEATURE_NAMES, TARGET_NAMES, Standardizer, load_energy, split_energy
from .network import Network, build_mlp, fit_iter, r2_score
from .optimizers import make_optimizer

ROOT = Path(__file__).resolve().parent.parent
MODEL_PATH = ROOT / "models" / "energy_numpy.npz"

DEFAULTS = dict(hidden=(64, 64), activation="relu", optimizer="adam", lr=2e-3,
                epochs=300, batch_size=32, seed=42)


def regression_metrics(net: Network, X, Y_std, y_scaler: Standardizer) -> dict:
    """R2 / RMSE / MAE per target, in the ORIGINAL units (kWh/m2)."""
    pred = y_scaler.inverse(net.predict(X))
    true = y_scaler.inverse(Y_std)
    r2 = r2_score(true, pred)
    rmse = np.sqrt(np.mean((true - pred) ** 2, axis=0))
    mae = np.mean(np.abs(true - pred), axis=0)
    return {t: {"r2": float(r2[i]), "rmse": float(rmse[i]), "mae": float(mae[i])}
            for i, t in enumerate(TARGET_NAMES)}


def train_energy(split: EnergySplit, hidden=DEFAULTS["hidden"], activation=DEFAULTS["activation"],
                 optimizer=DEFAULTS["optimizer"], lr=DEFAULTS["lr"], epochs=DEFAULTS["epochs"],
                 batch_size=DEFAULTS["batch_size"], seed=DEFAULTS["seed"], init_net: Network | None = None,
                 verbose: bool = False) -> dict:
    """Train on train, pick the best epoch on validation, evaluate on test ONCE at the end."""
    net = init_net.clone() if init_net is not None else build_mlp(
        split.Xtr.shape[1], hidden, split.Ytr.shape[1], activation, "regression", seed)
    opt = make_optimizer(optimizer, lr)
    history = {"train_loss": [], "val_loss": []}
    best_val, best_w, best_epoch = np.inf, net.get_weights(), 0
    for rec in fit_iter(net, opt, split.Xtr, split.Ytr, split.Xva, split.Yva, epochs, batch_size, seed):
        history["train_loss"].append(rec["train_loss"])
        history["val_loss"].append(rec["val_loss"])
        if rec["val_loss"] < best_val:
            best_val, best_w, best_epoch = rec["val_loss"], net.get_weights(), rec["epoch"]
        if verbose and rec["epoch"] % 25 == 0:
            print(f"  epoch {rec['epoch']:4d}  train {rec['train_loss']:.5f}  val {rec['val_loss']:.5f}")
    net.set_weights(best_w)
    return {
        "net": net, "history": history, "best_epoch": best_epoch,
        "val_metrics": regression_metrics(net, split.Xva, split.Yva, split.y_scaler),
        "test_metrics": regression_metrics(net, split.Xte, split.Yte, split.y_scaler),  # used once, at the end
    }


# ---------------------------------------------------------------- persistence
def save_model(net: Network, split: EnergySplit, meta: dict, path: Path = MODEL_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    arrays = {f"p{i}": p for i, p in enumerate(net.params())}
    np.savez(path, x_mean=split.x_scaler.mean, x_std=split.x_scaler.std,
             y_mean=split.y_scaler.mean, y_std=split.y_scaler.std, meta=json.dumps(meta), **arrays)


def load_model(path: Path = MODEL_PATH) -> dict:
    z = np.load(path, allow_pickle=False)
    meta = json.loads(str(z["meta"]))
    net = build_mlp(8, meta["hidden"], 2, meta["activation"], "regression", seed=0)
    net.set_weights([z[f"p{i}"] for i in range(len(net.params()))])
    return {"net": net, "meta": meta,
            "x_scaler": Standardizer(z["x_mean"], z["x_std"]),
            "y_scaler": Standardizer(z["y_mean"], z["y_std"])}


def train_and_save_default(epochs: int | None = None, verbose: bool = False) -> dict:
    data = load_energy()
    split = split_energy(data, seed=DEFAULTS["seed"])
    cfg = dict(DEFAULTS)
    if epochs:
        cfg["epochs"] = epochs
    res = train_energy(split, **cfg, verbose=verbose)
    meta = {"hidden": list(cfg["hidden"]), "activation": cfg["activation"], "optimizer": cfg["optimizer"],
            "lr": cfg["lr"], "epochs": cfg["epochs"], "best_epoch": res["best_epoch"],
            "dataset_source": data.source, "synthetic": data.is_synthetic,
            "test_metrics": res["test_metrics"], "feature_names": FEATURE_NAMES}
    save_model(res["net"], split, meta)
    return {"split": split, "data": data, "meta": meta, **res}


def predict_energy(model: dict, features: list[float]) -> dict:
    x = model["x_scaler"].transform(np.asarray(features, dtype=float).reshape(1, -1))
    y = model["y_scaler"].inverse(model["net"].predict(x))[0]
    return {"heating_load": float(y[0]), "cooling_load": float(y[1])}
