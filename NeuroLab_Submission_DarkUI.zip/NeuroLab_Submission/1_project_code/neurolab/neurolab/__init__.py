"""NeuroLab: a from-scratch NumPy neural network library and optimizer playground."""
__version__ = "1.0.0"
