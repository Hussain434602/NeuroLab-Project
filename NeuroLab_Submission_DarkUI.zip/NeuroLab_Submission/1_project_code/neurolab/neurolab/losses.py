"""Loss functions with hand-written gradients (mean over the batch)."""
from __future__ import annotations

import numpy as np


class Loss:
    def forward(self, pred, target) -> float:  # pragma: no cover - interface
        raise NotImplementedError

    def backward(self) -> np.ndarray:  # pragma: no cover - interface
        raise NotImplementedError


class MSE(Loss):
    """L = mean((pred - target)^2) over all N*D entries.  dL/dpred = 2 (pred - target) / (N*D)."""

    def forward(self, pred, target):
        self._diff = pred - target
        return float(np.mean(self._diff ** 2))

    def backward(self):
        return 2.0 * self._diff / self._diff.size


class CrossEntropy(Loss):
    """Categorical cross-entropy on *probabilities* (i.e. after a Softmax layer).

    ``target`` may be integer class labels (N,) or one-hot (N, C).
    L = -mean_n sum_c t_nc log p_nc            dL/dp_nc = -t_nc / (p_nc N)
    """

    EPS = 1e-12

    def forward(self, probs, target):
        target = np.asarray(target)
        if target.ndim == 1:
            onehot = np.zeros_like(probs)
            onehot[np.arange(len(target)), target.astype(int)] = 1.0
            target = onehot
        self._probs = np.clip(probs, self.EPS, 1.0)
        self._target = target
        return float(-np.sum(target * np.log(self._probs)) / probs.shape[0])

    def backward(self):
        return -self._target / (self._probs * self._probs.shape[0])
