# Results

Already generated (they need no dataset):
- `gradient_check.json` - numerical gradient check (44 checks, worst 8.3e-9)
- `optimizer_paths_rosenbrock.png`, `optimizer_paths_beale.png`, `optimizer_paths_summary.json`
- `decision_boundaries.png`, `classification_optimizers.png`, `classification_demos.json`
- `neuron_biological.png`, `neuron_artificial.png`

Generate with the REAL Energy Efficiency data (see the main README):
- `python -m experiments.train_energy` -> `energy_results.json`, `energy_loss_curves.png`, `energy_pred_vs_actual.png`
- `python -m experiments.compare_optimizers` -> `convergence_comparison.md`, `convergence_comparison.json`, `optimizer_convergence.png`

Then copy these numbers into the yellow fields of `docs/NeuroLab_Report.docx` (Tables 5 and 7).
