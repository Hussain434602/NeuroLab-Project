"""FastAPI server for NeuroLab.

Run locally:   uvicorn app.main:app --reload --port 8000
Open:          http://localhost:8000

Endpoints
    POST /api/train/stream   stream a live training run (NDJSON, one JSON object per line)
    GET  /api/energy/info    metadata + test metrics of the served Energy model
    POST /api/predict        heating / cooling load for one building design (logged)
    GET  /api/gradcheck      run the numerical gradient check
    GET  /api/health
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from neurolab.data import FEATURE_NAMES, FEATURE_RANGES
from neurolab.energy import MODEL_PATH, load_model, predict_energy, train_and_save_default
from neurolab.gradcheck import THRESHOLD, run_full_check
from neurolab.playground import validate_config, playground_stream

ROOT = Path(__file__).resolve().parent.parent
STATIC = Path(__file__).resolve().parent / "static"
LOG_PATH = ROOT / "logs" / "predictions.jsonl"

app = FastAPI(title="NeuroLab", version="1.0.0")

_model = None
_model_lock = threading.Lock()


def get_model() -> dict:
    """Load the trained Energy model; if none exists yet, train one (takes a few seconds)."""
    global _model
    with _model_lock:
        if _model is None:
            if not MODEL_PATH.exists():
                train_and_save_default()
            _model = load_model()
        return _model


# ------------------------------------------------------------------ schemas
class TrainOptimizer(BaseModel):
    name: str = "adam"
    lr: float = 0.01


class TrainRequest(BaseModel):
    dataset: str = "moons"
    hidden: list[int] = Field(default_factory=lambda: [8, 8])
    activation: str = "tanh"
    optimizers: list[TrainOptimizer] = Field(default_factory=lambda: [TrainOptimizer()])
    epochs: int = 100
    batch_size: int = 32
    seed: int = 0
    noise: float = 0.15
    viz_every: int = 5
    delay_ms: int = 15


class PredictRequest(BaseModel):
    features: list[float] = Field(..., min_length=8, max_length=8)


# ---------------------------------------------------------------- endpoints
@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/train/stream")
def train_stream(req: TrainRequest):
    cfg = req.model_dump()
    try:
        validate_config(cfg)  # fail fast with a clear 422 before streaming starts
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    def lines():
        try:
            for msg in playground_stream(cfg):
                yield json.dumps(msg) + "\n"
        except Exception as exc:  # surface errors to the UI instead of a silent hang
            yield json.dumps({"type": "error", "detail": str(exc)}) + "\n"

    return StreamingResponse(lines(), media_type="application/x-ndjson")


@app.get("/api/energy/info")
def energy_info():
    m = get_model()["meta"]
    return {**m, "feature_names": FEATURE_NAMES, "feature_ranges": FEATURE_RANGES}


@app.post("/api/predict")
def predict(req: PredictRequest):
    model = get_model()
    for value, (lo, hi), name in zip(req.features, FEATURE_RANGES, FEATURE_NAMES):
        if not (lo - 0.5 * (hi - lo) <= value <= hi + 0.5 * (hi - lo)):
            raise HTTPException(422, f"{name} = {value} is far outside the training range [{lo}, {hi}]")
    result = predict_energy(model, req.features)
    LOG_PATH.parent.mkdir(exist_ok=True)
    with LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "features": req.features, **result}) + "\n")
    return {**result, "synthetic_model": model["meta"].get("synthetic", False)}


@app.get("/api/gradcheck")
def gradcheck():
    rows = run_full_check()
    return {"threshold": THRESHOLD, "worst": max(r["rel_error"] for r in rows),
            "passed": all(r["passed"] for r in rows), "rows": rows}


# ------------------------------------------------------------------- pages
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/")
def index():
    return FileResponse(STATIC / "index.html")


@app.get("/neurons")
def neurons():
    return FileResponse(STATIC / "neurons.html")
