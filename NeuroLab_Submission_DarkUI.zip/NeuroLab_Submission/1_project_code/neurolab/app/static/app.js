"use strict";

/* ---------- small helpers ---------- */
const $ = (id) => document.getElementById(id);
const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
const fmt = (v, d = 4) => (v === null || v === undefined || !isFinite(v) ? "-" : Number(v).toPrecision(d));

/* ---------- tabs ---------- */
const tabs = [["tab-play", "panel-play"], ["tab-energy", "panel-energy"], ["tab-grad", "panel-grad"]];
tabs.forEach(([tabId, panelId]) => {
  $(tabId).addEventListener("click", () => {
    tabs.forEach(([t, p]) => {
      $(t).setAttribute("aria-selected", String(t === tabId));
      $(p).hidden = p !== panelId;
    });
    if (tabId === "tab-energy") initEnergy();
    if (tabId === "tab-play") redraw();
  });
});

/* =====================================================================
   PLAYGROUND
   ===================================================================== */
const state = { init: null, runs: [], controller: null, dirty: false, epochs: 0 };
const CLASS_COLORS = ["#f59e0b", "#60a5fa"];

const OPT_LABEL = { sgd: "SGD", momentum: "SGD + momentum", rmsprop: "RMSprop", adam: "Adam" };

$("noise").addEventListener("input", () => ($("noise-val").textContent = $("noise").value));
$("compare").addEventListener("change", () => ($("fs-b").disabled = !$("compare").checked));
$("dataset").addEventListener("change", () => {
  const energy = $("dataset").value === "energy";
  $("noise-row").hidden = energy;
  if (energy) {
    $("activation").value = "relu"; $("hidden").value = "32, 32"; $("lr-a").value = "0.003"; $("lr-b").value = "0.01";
    $("opt-b").value = "sgd"; $("epochs").value = "150";
  } else {
    $("activation").value = "tanh"; $("hidden").value = "8, 8"; $("lr-a").value = "0.01"; $("lr-b").value = "0.05";
    $("epochs").value = "120";
  }
});

function parseHidden() {
  const parts = $("hidden").value.split(",").map((s) => s.trim()).filter(Boolean);
  const nums = parts.map(Number);
  if (!nums.length || nums.some((n) => !Number.isInteger(n) || n < 1 || n > 64) || nums.length > 6) {
    throw new Error("Hidden layers must be 1 to 6 whole numbers between 1 and 64, for example 8, 8.");
  }
  return nums;
}

function buildRequest() {
  const optimizers = [{ name: $("opt-a").value, lr: parseFloat($("lr-a").value) }];
  if ($("compare").checked) optimizers.push({ name: $("opt-b").value, lr: parseFloat($("lr-b").value) });
  if (optimizers.some((o) => !(o.lr > 0))) throw new Error("Learning rate must be a positive number.");
  return {
    dataset: $("dataset").value, hidden: parseHidden(), activation: $("activation").value, optimizers,
    epochs: parseInt($("epochs").value, 10) || 100, batch_size: parseInt($("batch").value, 10) || 32,
    seed: parseInt($("seed").value, 10) || 0, noise: parseFloat($("noise").value),
    viz_every: parseInt($("viz-every").value, 10) || 5, delay_ms: 15,
  };
}

function setRunning(running) {
  $("start").disabled = running;
  $("stop").disabled = !running;
}

$("stop").addEventListener("click", () => state.controller && state.controller.abort());

$("start").addEventListener("click", async () => {
  $("play-error").textContent = "";
  let req;
  try { req = buildRequest(); } catch (e) { $("play-error").textContent = e.message; return; }

  state.init = null; state.runs = []; state.epochs = req.epochs;
  state.controller = new AbortController();
  $("synthetic-banner").hidden = true;
  setRunning(true);
  try {
    const resp = await fetch("/api/train/stream", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req), signal: state.controller.signal,
    });
    if (!resp.ok) {
      const body = await resp.json().catch(() => ({}));
      throw new Error(typeof body.detail === "string" ? body.detail : "The server rejected these settings.");
    }
    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buf = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      let nl;
      while ((nl = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, nl).trim();
        buf = buf.slice(nl + 1);
        if (line) handleMessage(JSON.parse(line));
      }
    }
  } catch (e) {
    if (e.name !== "AbortError") $("play-error").textContent = e.message || "Training failed. Check the server log.";
  } finally {
    setRunning(false);
    redraw();
  }
});

function handleMessage(m) {
  if (m.type === "init") {
    state.init = m;
    state.runs = m.runs.map((label, i) => ({
      label, color: i === 0 ? css("--run-a") : css("--run-b"), train: [], val: [], metric: null, viz: null, epoch: 0, diverged: false,
    }));
    $("synthetic-banner").hidden = !m.synthetic;
    buildCards();
  } else if (m.type === "epoch") {
    const r = state.runs[m.run];
    r.epoch = m.epoch;
    r.train.push(m.train_loss); r.val.push(m.val_loss);
    if (m.diverged) r.diverged = true;
    if (m.val_metric) r.metric = m.val_metric;
    if (m.viz) r.viz = m.viz;
    scheduleDraw();
  } else if (m.type === "error") {
    $("play-error").textContent = m.detail;
  }
}

function buildCards() {
  const wrap = $("viz-pair");
  wrap.innerHTML = "";
  state.runs.forEach((r, i) => {
    const card = document.createElement("div");
    card.className = "panel run-card " + (i === 0 ? "a" : "b");
    const title = state.init.task === "classification" ? "Decision boundary" : "Predicted vs actual (validation, heating load)";
    card.innerHTML = `<h3><span>Run ${i === 0 ? "A" : "B"}: ${r.label}</span></h3>
      <div class="stats" id="stats-${i}" aria-live="off"></div>
      <canvas id="viz-${i}" width="440" height="440" role="img" aria-label="${title}, run ${i === 0 ? "A" : "B"}"></canvas>
      <div class="hint">${title}</div>`;
    wrap.appendChild(card);
  });
  $("loss-legend").innerHTML = state.runs
    .map((r, i) => `<span><span class="swatch" style="background:${r.color}"></span>Run ${i === 0 ? "A" : "B"}: ${r.label}</span>`)
    .join("");
}

function scheduleDraw() {
  if (state.dirty) return;
  state.dirty = true;
  requestAnimationFrame(() => { state.dirty = false; redraw(); });
}

function redraw() {
  if (!state.init) { drawEmptyLoss(); return; }
  drawLoss();
  state.runs.forEach((r, i) => {
    const s = $("stats-" + i);
    if (s) {
      const last = r.train.length - 1;
      s.textContent = r.diverged
        ? `epoch ${r.epoch}: diverged (loss became infinite). Try a smaller learning rate.`
        : `epoch ${r.epoch}   train ${fmt(r.train[last])}   val ${fmt(r.val[last])}` +
          (r.metric ? `   ${r.metric.name} ${fmt(r.metric.value, 3)}` : "");
    }
    const c = $("viz-" + i);
    if (c && r.viz) {
      if (state.init.task === "classification") drawBoundary(c, r.viz.p1);
      else drawScatter(c, r.viz.actual, r.viz.pred, r.color);
    } else if (c && !r.viz) {
      clearCanvas(c);
    }
  });
}

function clearCanvas(c) {
  const ctx = c.getContext("2d");
  ctx.fillStyle = css("--panel"); ctx.fillRect(0, 0, c.width, c.height);
}

function drawEmptyLoss() {
  const c = $("loss-canvas");
  clearCanvas(c);
  const ctx = c.getContext("2d");
  ctx.fillStyle = css("--ink-soft"); ctx.font = "15px system-ui"; ctx.textAlign = "center";
  ctx.fillText("Press Train to start. The loss curve appears here as the network learns.", c.width / 2, c.height / 2);
}

function drawLoss() {
  const c = $("loss-canvas"), ctx = c.getContext("2d");
  const W = c.width, H = c.height, L = 62, R = 14, T = 12, B = 34;
  clearCanvas(c);
  const logY = $("log-y").checked;
  let vals = [];
  state.runs.forEach((r) => { vals = vals.concat(r.train, r.val); });
  vals = vals.filter((v) => v !== null && isFinite(v) && (!logY || v > 0));
  if (!vals.length) return;
  let lo = Math.min(...vals), hi = Math.max(...vals);
  if (logY) { lo = Math.log10(lo); hi = Math.log10(hi); }
  if (hi - lo < 1e-9) { hi += 0.5; lo -= 0.5; }
  const padY = (hi - lo) * 0.05; lo -= padY; hi += padY;
  const X = (e) => L + (e / Math.max(1, state.epochs)) * (W - L - R);
  const Y = (v) => { const t = logY ? Math.log10(v) : v; return T + (1 - (t - lo) / (hi - lo)) * (H - T - B); };

  ctx.strokeStyle = css("--grid"); ctx.fillStyle = css("--ink-soft"); ctx.lineWidth = 1; ctx.font = "12px system-ui";
  ctx.textAlign = "right";
  for (let i = 0; i <= 4; i++) {
    const t = lo + ((hi - lo) * i) / 4, y = T + (1 - i / 4) * (H - T - B);
    ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(W - R, y); ctx.stroke();
    ctx.fillText(logY ? Math.pow(10, t).toExponential(1) : t.toPrecision(2), L - 6, y + 4);
  }
  ctx.textAlign = "center";
  for (let i = 0; i <= 5; i++) {
    const e = Math.round((state.epochs * i) / 5);
    ctx.fillText(String(e), X(e), H - 12);
  }
  ctx.fillText("epoch", (L + W - R) / 2, H - 0);

  const line = (arr, color, dash) => {
    ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.setLineDash(dash);
    ctx.beginPath();
    let started = false;
    arr.forEach((v, e) => {
      if (v === null || !isFinite(v) || (logY && v <= 0)) return;
      const x = X(e), y = Y(v);
      if (!started) { ctx.moveTo(x, y); started = true; } else ctx.lineTo(x, y);
    });
    ctx.stroke(); ctx.setLineDash([]);
  };
  state.runs.forEach((r) => { line(r.train, r.color, []); line(r.val, r.color, [6, 4]); });
}
$("log-y").addEventListener("change", redraw);

function drawBoundary(canvas, p1) {
  const ctx = canvas.getContext("2d"), W = canvas.width, H = canvas.height;
  const G = state.init.grid, [x0, x1, y0, y1] = state.init.bounds;
  const off = document.createElement("canvas"); off.width = G; off.height = G;
  const octx = off.getContext("2d"), img = octx.createImageData(G, G);
  const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  const c0 = hex(CLASS_COLORS[0]), c1 = hex(CLASS_COLORS[1]);
  for (let r = 0; r < G; r++) {
    for (let col = 0; col < G; col++) {
      const p = p1[r * G + col], row = G - 1 - r, k = (row * G + col) * 4;
      for (let ch = 0; ch < 3; ch++) img.data[k + ch] = c0[ch] * (1 - p) + c1[ch] * p;
      img.data[k + 3] = 150;
    }
  }
  octx.putImageData(img, 0, 0);
  clearCanvas(canvas);
  ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high";
  ctx.drawImage(off, 0, 0, W, H);
  const px = (x) => ((x - x0) / (x1 - x0)) * W, py = (y) => H - ((y - y0) / (y1 - y0)) * H;
  const dots = (set, ring) => set.x.forEach((pt, i) => {
    ctx.beginPath(); ctx.arc(px(pt[0]), py(pt[1]), ring ? 4.2 : 3.4, 0, 2 * Math.PI);
    if (ring) { ctx.strokeStyle = CLASS_COLORS[set.y[i]]; ctx.lineWidth = 2; ctx.fillStyle = css("--panel"); ctx.fill(); ctx.stroke(); }
    else { ctx.fillStyle = CLASS_COLORS[set.y[i]]; ctx.strokeStyle = "rgba(255,255,255,.85)"; ctx.lineWidth = 1; ctx.fill(); ctx.stroke(); }
  });
  dots(state.init.train, false); dots(state.init.val, true);
}

function drawScatter(canvas, actual, pred, color) {
  const ctx = canvas.getContext("2d"), W = canvas.width, H = canvas.height, M = 44;
  clearCanvas(canvas);
  const all = actual.concat(pred);
  let lo = Math.min(...all), hi = Math.max(...all);
  const pad = (hi - lo) * 0.05 || 1; lo -= pad; hi += pad;
  const S = (v) => M + ((v - lo) / (hi - lo)) * (W - M - 12);
  const SY = (v) => H - M - ((v - lo) / (hi - lo)) * (H - M - 12);
  ctx.strokeStyle = css("--grid"); ctx.fillStyle = css("--ink-soft"); ctx.font = "12px system-ui"; ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const v = lo + ((hi - lo) * i) / 4;
    ctx.beginPath(); ctx.moveTo(S(v), 12); ctx.lineTo(S(v), H - M); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(M, SY(v)); ctx.lineTo(W - 12, SY(v)); ctx.stroke();
    ctx.textAlign = "center"; ctx.fillText(v.toFixed(0), S(v), H - M + 16);
    ctx.textAlign = "right"; ctx.fillText(v.toFixed(0), M - 6, SY(v) + 4);
  }
  ctx.textAlign = "center"; ctx.fillText("actual (kWh/m\u00B2)", W / 2, H - 6);
  ctx.save(); ctx.translate(12, H / 2); ctx.rotate(-Math.PI / 2); ctx.fillText("predicted", 0, 0); ctx.restore();
  ctx.strokeStyle = css("--ink"); ctx.setLineDash([6, 4]);
  ctx.beginPath(); ctx.moveTo(S(lo), SY(lo)); ctx.lineTo(S(hi), SY(hi)); ctx.stroke(); ctx.setLineDash([]);
  ctx.fillStyle = color; ctx.globalAlpha = 0.75;
  actual.forEach((a, i) => { ctx.beginPath(); ctx.arc(S(a), SY(pred[i]), 3.6, 0, 2 * Math.PI); ctx.fill(); });
  ctx.globalAlpha = 1;
}

drawEmptyLoss();

/* =====================================================================
   ENERGY PREDICTOR
   ===================================================================== */
let energyReady = false;
const DEFAULT_BUILDING = [0.9, 563.5, 318.5, 122.5, 7, 3, 0.25, 3];

async function initEnergy() {
  if (energyReady) return;
  $("energy-error").textContent = "Loading the model (the first call can take a few seconds)...";
  try {
    const resp = await fetch("/api/energy/info");
    if (!resp.ok) throw new Error("The model could not be loaded on the server.");
    const info = await resp.json();
    const box = $("energy-fields");
    box.innerHTML = "";
    info.feature_names.forEach((name, i) => {
      const [lo, hi] = info.feature_ranges[i];
      const step = i === 5 || i === 7 ? 1 : "any";
      const div = document.createElement("div");
      div.innerHTML = `<label for="f${i}">${name} <span class="hint">(${lo} to ${hi})</span></label>
        <input id="f${i}" type="number" step="${step}" value="${DEFAULT_BUILDING[i]}" required>`;
      box.appendChild(div);
    });
    $("energy-synth").hidden = !info.synthetic;
    const tbody = $("metrics-table").querySelector("tbody");
    tbody.innerHTML = "";
    Object.entries(info.test_metrics).forEach(([t, m]) => {
      tbody.insertAdjacentHTML("beforeend",
        `<tr><td>${t}</td><td class="num">${m.r2.toFixed(4)}</td><td class="num">${m.rmse.toFixed(3)}</td><td class="num">${m.mae.toFixed(3)}</td></tr>`);
    });
    $("model-desc").textContent =
      `Network ${info.hidden.join("-")} (${info.activation}), trained with ${info.optimizer} at lr ${info.lr}; best epoch ${info.best_epoch}. Data: ${info.dataset_source}.`;
    energyReady = true;
    $("energy-error").textContent = "";
  } catch (e) {
    $("energy-error").textContent = e.message;
  }
}

$("predict-btn").addEventListener("click", async () => {
  $("energy-error").textContent = "";
  const features = [];
  for (let i = 0; i < 8; i++) {
    const el = $("f" + i);
    if (!el) { $("energy-error").textContent = "The form is still loading. Try again in a moment."; return; }
    const v = parseFloat(el.value);
    if (!isFinite(v)) { $("energy-error").textContent = "Fill in every field with a number."; return; }
    features.push(v);
  }
  try {
    const resp = await fetch("/api/predict", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ features }) });
    const body = await resp.json();
    if (!resp.ok) throw new Error(typeof body.detail === "string" ? body.detail : "Those values were rejected. Check the ranges shown next to each field.");
    $("out-heat").textContent = body.heating_load.toFixed(2);
    $("out-cool").textContent = body.cooling_load.toFixed(2);
  } catch (e) {
    $("energy-error").textContent = e.message;
  }
});

/* =====================================================================
   GRADIENT CHECK
   ===================================================================== */
$("grad-btn").addEventListener("click", async () => {
  $("grad-summary").textContent = "Running...";
  try {
    const resp = await fetch("/api/gradcheck");
    if (!resp.ok) throw new Error("The gradient check failed to run on the server.");
    const g = await resp.json();
    $("grad-summary").innerHTML = `${g.passed ? '<span class="pass">All checks passed.</span>' : '<span class="fail">Some checks failed.</span>'} ` +
      `Worst relative error ${g.worst.toExponential(2)} (limit ${g.threshold.toExponential(0)}).`;
    const tbody = $("grad-table").querySelector("tbody");
    tbody.innerHTML = g.rows.map((r) =>
      `<tr><td>${r.layer}</td><td>${r.param}</td><td class="num">${r.rel_error.toExponential(2)}</td>` +
      `<td class="${r.passed ? "pass" : "fail"}">${r.passed ? "pass" : "fail"}</td></tr>`).join("");
    $("grad-table").hidden = false;
  } catch (e) {
    $("grad-summary").innerHTML = `<span class="fail">${e.message}</span>`;
  }
});
