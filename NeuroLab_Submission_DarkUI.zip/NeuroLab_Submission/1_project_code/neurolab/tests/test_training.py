import numpy as np

from neurolab.data import make_classification_data
from neurolab.network import build_mlp, fit_iter
from neurolab.optimizers import make_optimizer
from neurolab.playground import playground_stream, validate_config
import pytest


def test_moons_are_learned():
    Xtr, ytr, Xva, yva = make_classification_data("moons", seed=0)
    net = build_mlp(2, [16, 16], 2, "tanh", "classification", seed=0)
    for _ in fit_iter(net, make_optimizer("adam", 0.01), Xtr, ytr, Xva, yva, 80, 32, 0):
        pass
    assert (net.predict(Xva).argmax(1) == yva).mean() > 0.9


def test_same_seed_is_deterministic():
    Xtr, ytr, Xva, yva = make_classification_data("circles", seed=1)
    losses = []
    for _ in range(2):
        net = build_mlp(2, [8], 2, "relu", "classification", seed=5)
        last = list(fit_iter(net, make_optimizer("sgd", 0.05), Xtr, ytr, Xva, yva, 5, 32, 5))[-1]
        losses.append(last["val_loss"])
    assert losses[0] == losses[1]


def test_playground_two_runs_share_initial_loss():
    cfg = {"dataset": "moons", "optimizers": [{"name": "sgd", "lr": 0.05}, {"name": "adam", "lr": 0.01}],
           "epochs": 3, "delay_ms": 0}
    msgs = list(playground_stream(cfg))
    epoch0 = [m for m in msgs if m["type"] == "epoch" and m["epoch"] == 0]
    assert len(epoch0) == 2 and epoch0[0]["train_loss"] == epoch0[1]["train_loss"]
    assert msgs[-1]["type"] == "done"


def test_validate_rejects_bad_input():
    with pytest.raises(ValueError):
        validate_config({"dataset": "nope"})
    with pytest.raises(ValueError):
        validate_config({"optimizers": [{"name": "adam", "lr": 100}]})
    with pytest.raises(ValueError):
        validate_config({"hidden": []})
