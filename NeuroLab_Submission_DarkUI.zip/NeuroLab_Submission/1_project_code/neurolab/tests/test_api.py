import json

import pytest

pytest.importorskip("fastapi")
pytest.importorskip("httpx")
from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

client = TestClient(app)


def test_health():
    assert client.get("/api/health").json() == {"status": "ok"}


def test_stream_returns_ndjson():
    r = client.post("/api/train/stream", json={"dataset": "moons", "epochs": 3, "delay_ms": 0})
    assert r.status_code == 200
    msgs = [json.loads(l) for l in r.text.splitlines() if l]
    assert msgs[0]["type"] == "init" and msgs[-1]["type"] == "done"


def test_stream_rejects_bad_optimizer():
    r = client.post("/api/train/stream", json={"optimizers": [{"name": "bogus", "lr": 0.1}]})
    assert r.status_code == 422


def test_predict_and_validation():
    ok = client.post("/api/predict", json={"features": [0.9, 563.5, 318.5, 122.5, 7, 3, 0.25, 3]})
    assert ok.status_code == 200 and {"heating_load", "cooling_load"} <= set(ok.json())
    assert client.post("/api/predict", json={"features": [1, 2, 3]}).status_code == 422
    assert client.post("/api/predict", json={"features": [50, 563.5, 318.5, 122.5, 7, 3, 0.25, 3]}).status_code == 422


def test_gradcheck_endpoint():
    assert client.get("/api/gradcheck").json()["passed"] is True
