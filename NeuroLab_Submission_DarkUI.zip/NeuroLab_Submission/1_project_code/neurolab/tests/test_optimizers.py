import numpy as np
import pytest

from neurolab.optimizers import Adam, Momentum, RMSprop, SGD, make_optimizer


def test_sgd_single_step():
    p = np.array([1.0, 2.0]); SGD(0.1).step([p], [np.array([1.0, -1.0])])
    np.testing.assert_allclose(p, [0.9, 2.1])


def test_momentum_accumulates():
    p = np.array([0.0]); opt = Momentum(0.1, 0.9); g = [np.array([1.0])]
    opt.step([p], g); opt.step([p], g)
    # v1 = -0.1 ; v2 = 0.9*-0.1 - 0.1 = -0.19 ; p = -0.29
    np.testing.assert_allclose(p, [-0.29])


def test_adam_first_step_is_lr_sized():
    # after bias correction the very first Adam step is ~ lr * sign(g)
    p = np.array([0.0]); Adam(0.01).step([p], [np.array([123.0])])
    np.testing.assert_allclose(p, [-0.01], rtol=1e-6)


@pytest.mark.parametrize("name,lr", [("sgd", 0.1), ("momentum", 0.05), ("rmsprop", 0.05), ("adam", 0.1)])
def test_all_minimise_a_quadratic(name, lr):
    p = np.array([3.0, -2.0]); opt = make_optimizer(name, lr)
    for _ in range(400):
        opt.step([p], [2 * p])  # gradient of |p|^2
    assert np.linalg.norm(p) < 0.1


def test_unknown_optimizer():
    with pytest.raises(ValueError):
        make_optimizer("nope", 0.1)
