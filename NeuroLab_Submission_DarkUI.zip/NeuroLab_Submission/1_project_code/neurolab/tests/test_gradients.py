"""Every hand-written backward pass must match finite differences (rel. error < 1e-5)."""
import numpy as np
import pytest

from neurolab.gradcheck import THRESHOLD, check_activation, check_loss, check_network, run_full_check
from neurolab.activations import ACTIVATIONS
from neurolab.network import build_mlp


@pytest.mark.parametrize("name", sorted(ACTIVATIONS))
def test_activation_gradients(name):
    assert check_activation(name, np.random.default_rng(1))["rel_error"] < THRESHOLD


@pytest.mark.parametrize("name", ["mse", "cross_entropy"])
def test_loss_gradients(name):
    assert check_loss(name, np.random.default_rng(2))["rel_error"] < THRESHOLD


@pytest.mark.parametrize("act", ["sigmoid", "tanh", "relu", "leaky_relu"])
@pytest.mark.parametrize("task", ["regression", "classification"])
def test_full_network(act, task):
    rng = np.random.default_rng(3)
    net = build_mlp(4, [6, 5], 3, act, task, seed=3)
    y = rng.normal(size=(7, 3)) if task == "regression" else rng.integers(0, 3, size=7)
    for row in check_network(net, rng.normal(size=(7, 4)), y):
        assert row["rel_error"] < THRESHOLD, row


def test_run_full_check_all_pass():
    assert all(r["passed"] for r in run_full_check())
