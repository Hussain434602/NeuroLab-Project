"""Train the multi-output regressor from scratch (NumPy) and rebuild it in PyTorch.

    python -m experiments.train_energy            # NumPy + PyTorch (if installed)
    python -m experiments.train_energy --no-torch

Outputs (in results/): energy_results.json, energy_loss_curves.png,
energy_pred_vs_actual.png, and models/energy_numpy.npz for the web app.
The test set is evaluated exactly once per model, after model selection on validation.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from neurolab.data import TARGET_NAMES, load_energy, split_energy
from neurolab.energy import DEFAULTS, save_model, train_energy
from neurolab.network import build_mlp

RESULTS = Path(__file__).resolve().parent.parent / "results"
R2_TARGET = 0.95


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-torch", action="store_true")
    ap.add_argument("--epochs", type=int, default=DEFAULTS["epochs"])
    args = ap.parse_args()
    RESULTS.mkdir(exist_ok=True)

    data = load_energy()
    print(f"dataset source: {data.source}   samples: {len(data.X)}")
    if data.is_synthetic:
        print("*** SYNTHETIC DATA - these numbers are NOT valid results. Add data/ENB2012_data.xlsx. ***")
    split = split_energy(data, seed=DEFAULTS["seed"])
    print(f"split  train={len(split.Xtr)}  val={len(split.Xva)}  test={len(split.Xte)}")

    cfg = dict(DEFAULTS)
    cfg["epochs"] = args.epochs
    init_net = build_mlp(8, cfg["hidden"], 2, cfg["activation"], "regression", cfg["seed"])
    print("\n[NumPy, from scratch]", init_net.summary())
    np_res = train_energy(split, **cfg, init_net=init_net, verbose=True)
    results = {"dataset_source": data.source, "config": {k: list(v) if isinstance(v, tuple) else v for k, v in cfg.items()},
               "numpy": {"best_epoch": np_res["best_epoch"], "test": np_res["test_metrics"],
                         "val": np_res["val_metrics"]}}
    save_model(np_res["net"], split, {"hidden": list(cfg["hidden"]), "activation": cfg["activation"],
                                      "optimizer": cfg["optimizer"], "lr": cfg["lr"], "epochs": cfg["epochs"],
                                      "best_epoch": np_res["best_epoch"], "dataset_source": data.source,
                                      "synthetic": data.is_synthetic, "test_metrics": np_res["test_metrics"]})

    torch_runs = {}
    if not args.no_torch:
        try:
            from neurolab.torch_baseline import train_torch
            print("\n[PyTorch, same initial weights + same batches]")
            torch_runs["same_init"] = train_torch(split, cfg["hidden"], cfg["activation"], cfg["lr"], cfg["epochs"],
                                                  cfg["batch_size"], cfg["seed"], numpy_init=init_net, same_init=True, verbose=True)
            print("\n[PyTorch, default nn.Linear initialisation]")
            torch_runs["default_init"] = train_torch(split, cfg["hidden"], cfg["activation"], cfg["lr"], cfg["epochs"],
                                                     cfg["batch_size"], cfg["seed"], same_init=False, verbose=True)
            results["torch"] = {k: {"best_epoch": v["best_epoch"], "test": v["test_metrics"]} for k, v in torch_runs.items()}
        except RuntimeError as exc:
            print("PyTorch skipped:", exc)

    (RESULTS / "energy_results.json").write_text(json.dumps(results, indent=2))

    # ------------------------------------------------------------------ report
    print("\n" + "=" * 68)
    print(f"{'model':<28}{'target':<14}{'test R2':>9}{'RMSE':>9}")
    rows = [("NumPy (scratch)", np_res["test_metrics"])]
    for k, v in torch_runs.items():
        rows.append((f"PyTorch ({k})", v["test_metrics"]))
    for name, m in rows:
        for t in TARGET_NAMES:
            print(f"{name:<28}{t:<14}{m[t]['r2']:>9.4f}{m[t]['rmse']:>9.3f}")
    ok = np_res["test_metrics"]["Heating load"]["r2"] >= R2_TARGET
    print("=" * 68)
    print(f"success criterion heating-load test R2 >= {R2_TARGET}: {'PASS' if ok else 'FAIL'}"
          + ("  (synthetic data - not valid)" if data.is_synthetic else ""))

    # ------------------------------------------------------------------- plots
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(np_res["history"]["train_loss"], label="NumPy train", color="#0b7285")
    ax.plot(np_res["history"]["val_loss"], label="NumPy val", color="#0b7285", ls="--")
    if "same_init" in torch_runs:
        ax.plot(torch_runs["same_init"]["history"]["val_loss"], label="PyTorch val (same init)", color="#b5179e", ls=":")
    if "default_init" in torch_runs:
        ax.plot(torch_runs["default_init"]["history"]["val_loss"], label="PyTorch val (default init)", color="#e9a100", ls=":")
    ax.set_yscale("log"); ax.set_xlabel("epoch"); ax.set_ylabel("MSE (standardised targets)")
    ax.set_title("Energy Efficiency: training curves"); ax.legend(); fig.tight_layout()
    fig.savefig(RESULTS / "energy_loss_curves.png", dpi=140); plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    net = np_res["net"]
    pred = split.y_scaler.inverse(net.predict(split.Xte))
    true = split.y_scaler.inverse(split.Yte)
    for i, ax in enumerate(axes):
        ax.scatter(true[:, i], pred[:, i], s=14, color="#0b7285", alpha=0.75)
        lim = [min(true[:, i].min(), pred[:, i].min()), max(true[:, i].max(), pred[:, i].max())]
        ax.plot(lim, lim, "k--", lw=1)
        ax.set_title(f"{TARGET_NAMES[i]}  (test R2 = {np_res['test_metrics'][TARGET_NAMES[i]]['r2']:.3f})")
        ax.set_xlabel("actual (kWh/m2)"); ax.set_ylabel("predicted (kWh/m2)")
    fig.tight_layout(); fig.savefig(RESULTS / "energy_pred_vs_actual.png", dpi=140); plt.close(fig)
    print("\nsaved plots + energy_results.json in results/, model in models/energy_numpy.npz")


if __name__ == "__main__":
    main()
