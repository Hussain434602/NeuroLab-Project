"""Classification demos on moons / circles / spiral (no download needed).

    python -m experiments.classification_demos

Produces results/decision_boundaries.png (Adam, tanh vs ReLU) and
results/classification_optimizers.png (four optimizers, same initial weights and batches),
plus results/classification_demos.json with the numbers quoted in the report.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from neurolab.data import make_classification_data
from neurolab.network import build_mlp, fit_iter
from neurolab.optimizers import make_optimizer

RESULTS = Path(__file__).resolve().parent.parent / "results"
SEED, EPOCHS, BATCH = 0, 150, 32
COLORS = {"sgd": "#6c757d", "momentum": "#2a9d8f", "rmsprop": "#e9a100", "adam": "#c1121f"}
LRS = {"sgd": 0.1, "momentum": 0.03, "rmsprop": 0.005, "adam": 0.01}


def train(name, act, opt, lr, hidden=(16, 16), init=None):
    Xtr, ytr, Xva, yva = make_classification_data(name, seed=SEED)
    net = init.clone() if init is not None else build_mlp(2, hidden, 2, act, "classification", SEED)
    curve = [r["val_loss"] for r in fit_iter(net, make_optimizer(opt, lr), Xtr, ytr, Xva, yva, EPOCHS, BATCH, SEED)]
    acc = float((net.predict(Xva).argmax(1) == yva).mean())
    return net, curve, acc, (Xtr, ytr, Xva, yva)


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    RESULTS.mkdir(exist_ok=True)
    out = {"boundaries": {}, "optimizers": {}}
    cmap = matplotlib.colors.ListedColormap(["#f4c58f", "#9cc3e6"])

    fig, axes = plt.subplots(2, 3, figsize=(12, 7.6))
    for r, act in enumerate(("tanh", "relu")):
        for c, ds in enumerate(("moons", "circles", "spiral")):
            net, _, acc, (Xtr, ytr, Xva, yva) = train(ds, act, "adam", 0.01)
            ax = axes[r, c]
            gx, gy = np.meshgrid(np.linspace(-2.4, 2.4, 200), np.linspace(-2.4, 2.4, 200))
            p = net.predict(np.column_stack([gx.ravel(), gy.ravel()]))[:, 1].reshape(gx.shape)
            ax.contourf(gx, gy, p, levels=[0, 0.5, 1], cmap=cmap, alpha=0.9)
            ax.scatter(*Xtr.T, c=np.where(ytr == 1, "#1f5fa8", "#d9730d"), s=10, edgecolors="white", linewidths=0.3)
            ax.set_xlim(-2.4, 2.4); ax.set_ylim(-2.4, 2.4); ax.set_xticks([]); ax.set_yticks([])
            ax.set_title(f"{ds}, {act}: val acc {acc:.3f}")
            out["boundaries"][f"{ds}/{act}"] = acc
    fig.suptitle("Decision boundaries learned with Adam (2 hidden layers of 16 neurons, 150 epochs)")
    fig.tight_layout(); fig.savefig(RESULTS / "decision_boundaries.png", dpi=130); plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(13, 4))
    for ax, ds in zip(axes, ("moons", "circles", "spiral")):
        init = build_mlp(2, (16, 16), 2, "tanh", "classification", SEED)
        out["optimizers"][ds] = {}
        for opt in ("sgd", "momentum", "rmsprop", "adam"):
            _, curve, acc, _ = train(ds, "tanh", opt, LRS[opt], init=init)
            ax.plot(curve, color=COLORS[opt], label=f"{opt} (lr={LRS[opt]:g})")
            out["optimizers"][ds][opt] = {"lr": LRS[opt], "final_val_loss": curve[-1], "val_acc": acc,
                                          "epochs_to_loss_below_0.2": next((i for i, v in enumerate(curve) if v < 0.2), None)}
        ax.set_yscale("log"); ax.set_title(ds); ax.set_xlabel("epoch"); ax.set_ylabel("validation cross-entropy")
    axes[0].legend(fontsize=8); fig.suptitle("Four optimizers from the same initial weights and batch order (tanh, 16-16)")
    fig.tight_layout(); fig.savefig(RESULTS / "classification_optimizers.png", dpi=130); plt.close(fig)

    (RESULTS / "classification_demos.json").write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()
