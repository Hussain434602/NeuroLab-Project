"""Optimizer paths on the Rosenbrock and Beale test surfaces.

    python -m experiments.optimizer_surfaces

Writes results/optimizer_paths_rosenbrock.png, ..._beale.png and
results/optimizer_paths_summary.json.  Uses the SAME hand-written optimizers as
the neural network code (they only see a list of arrays and gradients).
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from neurolab.optimizers import make_optimizer

RESULTS = Path(__file__).resolve().parent.parent / "results"


def rosenbrock(p):  # global minimum 0 at (1, 1)
    x, y = p
    return (1 - x) ** 2 + 100 * (y - x ** 2) ** 2


def rosenbrock_grad(p):
    x, y = p
    return np.array([-2 * (1 - x) - 400 * x * (y - x ** 2), 200 * (y - x ** 2)])


def beale(p):  # global minimum 0 at (3, 0.5)
    x, y = p
    return ((1.5 - x + x * y) ** 2 + (2.25 - x + x * y ** 2) ** 2 + (2.625 - x + x * y ** 3) ** 2)


def beale_grad(p):
    x, y = p
    a, b, c = 1.5 - x + x * y, 2.25 - x + x * y ** 2, 2.625 - x + x * y ** 3
    return np.array([2 * a * (y - 1) + 2 * b * (y ** 2 - 1) + 2 * c * (y ** 3 - 1),
                     2 * a * x + 4 * b * x * y + 6 * c * x * y ** 2])


SURFACES = {
    "rosenbrock": dict(f=rosenbrock, g=rosenbrock_grad, start=(-1.5, 2.0), optimum=(1.0, 1.0),
                       xlim=(-2, 2), ylim=(-1, 3), steps=3000,
                       lrs={"sgd": 2e-4, "momentum": 5e-5, "rmsprop": 5e-3, "adam": 2e-2}, log_levels=True),
    "beale": dict(f=beale, g=beale_grad, start=(-1.0, -1.5), optimum=(3.0, 0.5),
                  xlim=(-4.5, 4.5), ylim=(-4.5, 4.5), steps=3000,
                  lrs={"sgd": 1e-3, "momentum": 2e-4, "rmsprop": 5e-2, "adam": 1e-1}, log_levels=True),
}
COLORS = {"sgd": "#6c757d", "momentum": "#2a9d8f", "rmsprop": "#e9a100", "adam": "#c1121f"}


def run(surface: dict, name: str, clip: float = 1e6):
    p = np.array(surface["start"], dtype=float)
    opt = make_optimizer(name, surface["lrs"][name])
    path = [p.copy()]
    for _ in range(surface["steps"]):
        g = surface["g"](p)
        opt.step([p], [g])
        if not np.all(np.isfinite(p)) or np.abs(p).max() > clip:
            break
        path.append(p.copy())
    return np.array(path)


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    RESULTS.mkdir(exist_ok=True)
    summary = {}
    for sname, s in SURFACES.items():
        fig, ax = plt.subplots(figsize=(7, 6))
        xs, ys = np.linspace(*s["xlim"], 300), np.linspace(*s["ylim"], 300)
        xx, yy = np.meshgrid(xs, ys)
        zz = s["f"]((xx, yy))
        levels = np.logspace(-1, np.log10(zz.max()), 25)
        ax.contour(xx, yy, zz, levels=levels, colors="#8fa6bb", linewidths=0.7)
        summary[sname] = {}
        for name in ("sgd", "momentum", "rmsprop", "adam"):
            path = run(s, name)
            ax.plot(path[:, 0], path[:, 1], color=COLORS[name], lw=2.0, label=f"{name} (lr={s['lrs'][name]:g})")
            ax.plot(path[-1, 0], path[-1, 1], "o", color=COLORS[name], ms=7, mec="white", zorder=5)
            final = float(s["f"](path[-1]))
            dist = float(np.linalg.norm(path[-1] - np.array(s["optimum"])))
            # first step at which f drops below 1e-2 (nan if never)
            fvals = np.array([s["f"](q) for q in path])
            hit = np.argmax(fvals < 1e-2) if (fvals < 1e-2).any() else None
            summary[sname][name] = {"lr": s["lrs"][name], "final_f": final, "dist_to_optimum": dist,
                                    "steps_to_f_below_1e-2": None if hit is None else int(hit)}
        ax.plot(*s["start"], "ks", ms=7, label="start")
        ax.plot(*s["optimum"], "k*", ms=13, label="minimum")
        ax.set_xlim(s["xlim"]); ax.set_ylim(s["ylim"])
        ax.set_title(f"Optimizer paths on the {sname.capitalize()} function ({s['steps']} steps)")
        ax.set_xlabel("x"); ax.set_ylabel("y"); ax.legend(loc="upper left", fontsize=8)
        fig.tight_layout()
        fig.savefig(RESULTS / f"optimizer_paths_{sname}.png", dpi=140)
        plt.close(fig)
    (RESULTS / "optimizer_paths_summary.json").write_text(json.dumps(summary, indent=2))
    for sname, res in summary.items():
        print(f"\n{sname}")
        for name, r in res.items():
            print(f"  {name:<9} lr={r['lr']:<7g} final f={r['final_f']:.3e}  dist={r['dist_to_optimum']:.3f}  "
                  f"steps to f<1e-2: {r['steps_to_f_below_1e-2']}")


if __name__ == "__main__":
    main()
