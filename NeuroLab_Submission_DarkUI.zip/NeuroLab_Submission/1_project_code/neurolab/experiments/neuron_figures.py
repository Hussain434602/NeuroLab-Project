"""Draw our own diagrams of a biological and an artificial neuron for the report.

    python -m experiments.neuron_figures   ->  results/neuron_biological.png, results/neuron_artificial.png
"""
from pathlib import Path

RESULTS = Path(__file__).resolve().parent.parent / "results"
TEAL, MAG, INK, GOLD = "#0b7285", "#a61e8c", "#16233b", "#f4c26b"


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle, Ellipse, FancyBboxPatch

    RESULTS.mkdir(exist_ok=True)

    # ---- biological ----
    fig, ax = plt.subplots(figsize=(10, 4)); ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis("off")
    for x, y in ((4, 34), (2, 21), (5, 8), (11, 38)):
        ax.plot([x, 21, 21], [y, 20, 20][:3] if False else [y, 20 + (y - 20) * 0.15, 20], color=TEAL, lw=2.5)
        ax.plot([x, x - 2], [y, y + 2], color=TEAL, lw=1.8); ax.plot([x, x - 2], [y, y - 2], color=TEAL, lw=1.8)
    ax.add_patch(Ellipse((25, 20), 13, 12, fc="#cfeef3", ec=TEAL, lw=2.5))
    ax.add_patch(Circle((25, 20), 2.8, fc=TEAL))
    ax.plot([31.5, 82], [20, 20], color=TEAL, lw=3)
    for x in (37, 48, 59, 70):
        ax.add_patch(FancyBboxPatch((x, 18.4), 8, 3.2, boxstyle="round,pad=0,rounding_size=1.6", fc=GOLD, ec="#a66f00", lw=1.5))
    for y in (28, 20, 12):
        ax.plot([82, 92], [20, y], color=TEAL, lw=2.5); ax.add_patch(Circle((92.6, y), 1.1, fc=MAG))
    kw = dict(fontsize=10, color=INK)
    ax.text(2, 1.5, "Dendrites receive signals", **kw)
    ax.text(18, 29.5, "Cell body sums the inputs", **kw)
    ax.text(45, 25, "Axon carries the spike", **kw)
    ax.text(43, 14, "myelin sheaths speed it up", fontsize=9, color="#7a4d00")
    ax.text(70, 5, "Synapses pass the signal on", **kw)
    ax.set_title("Biological neuron (our sketch)", color=INK)
    fig.savefig(RESULTS / "neuron_biological.png", dpi=150, bbox_inches="tight"); plt.close(fig)

    # ---- artificial ----
    fig, ax = plt.subplots(figsize=(10, 4)); ax.set_xlim(0, 100); ax.set_ylim(0, 40); ax.axis("off")
    ys = (32, 20, 8)
    for i, y in enumerate(ys, 1):
        ax.add_patch(Circle((8, y), 3, fc="#cfeef3", ec=TEAL, lw=2)); ax.text(8, y, f"x{i}", ha="center", va="center", color=INK)
        ax.annotate("", xy=(38, 20 + (y - 20) * 0.35), xytext=(11, y), arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.5))
        ax.text(22, y * 0.6 + 8.6 if y != 20 else 21.2, f"w{i}", color=TEAL, fontsize=11)
    ax.add_patch(Circle((43, 20), 5, fc="#cfeef3", ec=TEAL, lw=2.5)); ax.text(43, 20, "\u03a3", ha="center", va="center", fontsize=20, color=INK)
    ax.text(43, 11.5, "+ bias b", ha="center", color=INK)
    ax.annotate("", xy=(60, 20), xytext=(48, 20), arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.5))
    ax.add_patch(FancyBboxPatch((60, 14), 16, 12, boxstyle="round,pad=0,rounding_size=1.5", fc="#f6dff1", ec=MAG, lw=2))
    import numpy as np
    t = np.linspace(-1, 1, 50); ax.plot(64 + (t + 1) * 4, 20 + 3.5 * np.tanh(3 * t), color=MAG, lw=2.5)
    ax.text(68, 27.5, "f(z)", ha="center", color=MAG)
    ax.annotate("", xy=(92, 20), xytext=(76, 20), arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.5)); ax.text(94, 20, "y", va="center", fontsize=13, color=INK)
    ax.text(4, 1.5, "Inputs", color=INK); ax.text(17, 1.5, "Weights (learned)", color=TEAL)
    ax.text(36, 1.5, "z = w\u00b7x + b", color=INK); ax.text(62, 1.5, "Activation", color=MAG); ax.text(85, 1.5, "Output", color=INK)
    ax.set_title("Artificial neuron: y = f(w\u00b7x + b)", color=INK)
    fig.savefig(RESULTS / "neuron_artificial.png", dpi=150, bbox_inches="tight"); plt.close(fig)


if __name__ == "__main__":
    main()
