"""Written comparison of convergence speed for SGD, momentum, RMSprop and Adam.

    python -m experiments.compare_optimizers

For fairness every optimizer (a) starts from the SAME initial weights, (b) sees the
SAME mini-batch order, and (c) gets its own learning rate chosen from a small grid by
validation loss.  Metric: number of epochs until validation MSE (standardised units)
first drops below THRESHOLD, plus the final validation MSE.

Writes results/convergence_comparison.md (table + auto-generated summary) and
results/optimizer_convergence.png.  The test set is not touched here.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from neurolab.data import load_energy, split_energy
from neurolab.network import build_mlp, fit_iter
from neurolab.optimizers import make_optimizer

RESULTS = Path(__file__).resolve().parent.parent / "results"
GRID = {"sgd": [0.003, 0.01, 0.03, 0.1], "momentum": [0.001, 0.003, 0.01, 0.03],
        "rmsprop": [0.0003, 0.001, 0.003, 0.01], "adam": [0.0003, 0.001, 0.003, 0.01]}
THRESHOLD = 0.05      # val MSE on standardised targets (~ R2 0.95)
EPOCHS, BATCH, SEED = 150, 32, 42
HIDDEN, ACT = (64, 64), "relu"


def run_one(split, init_net, name, lr):
    net = init_net.clone()
    opt = make_optimizer(name, lr)
    val = [r["val_loss"] for r in fit_iter(net, opt, split.Xtr, split.Ytr, split.Xva, split.Yva, EPOCHS, BATCH, SEED)]
    val = [v if np.isfinite(v) else np.inf for v in val]
    return val


def first_below(curve, thr):
    hit = next((i for i, v in enumerate(curve) if v < thr), None)
    return hit


def main():
    RESULTS.mkdir(exist_ok=True)
    data = load_energy()
    split = split_energy(data, seed=SEED)
    init_net = build_mlp(8, HIDDEN, 2, ACT, "regression", SEED)

    best = {}
    for name, lrs in GRID.items():
        runs = {lr: run_one(split, init_net, name, lr) for lr in lrs}
        lr_best = min(runs, key=lambda lr: min(runs[lr]))
        best[name] = {"lr": lr_best, "curve": runs[lr_best], "grid": {str(lr): min(c) for lr, c in runs.items()}}
        print(f"{name:<9} best lr {lr_best:<7g} min val MSE {min(runs[lr_best]):.5f}")

    rows = []
    for name, b in best.items():
        c = b["curve"]
        rows.append({"optimizer": name, "lr": b["lr"], "epochs_to_threshold": first_below(c, THRESHOLD),
                     "epochs_to_0.01": first_below(c, 0.01), "final_val_mse": c[-1], "best_val_mse": min(c)})

    def fmt(v): return "not reached" if v is None else str(v)
    lines = [f"# Convergence comparison: SGD vs momentum vs RMSprop vs Adam", "",
             f"Dataset: UCI Energy Efficiency ({data.source}); network {HIDDEN} {ACT}; batch {BATCH}; {EPOCHS} epochs; "
             f"same initial weights and same batch order for every optimizer; learning rate chosen from a grid "
             f"by best validation MSE. Loss is MSE on standardised targets (a value of 0.05 is roughly R2 = 0.95).", ""]
    if data.is_synthetic:
        lines += ["> **WARNING: produced on the synthetic stand-in dataset. Re-run with the real data before submitting.**", ""]
    lines += ["| Optimizer | Best lr | Epochs to val MSE < 0.05 | Epochs to val MSE < 0.01 | Final val MSE | Best val MSE |",
              "|---|---|---|---|---|---|"]
    for r in rows:
        lines.append(f"| {r['optimizer']} | {r['lr']:g} | {fmt(r['epochs_to_threshold'])} | {fmt(r['epochs_to_0.01'])} | "
                     f"{r['final_val_mse']:.5f} | {r['best_val_mse']:.5f} |")
    reached = [r for r in rows if r["epochs_to_threshold"] is not None]
    lines += ["", "## Summary of what the numbers show", ""]
    if reached:
        order = sorted(reached, key=lambda r: r["epochs_to_threshold"])
        lines.append("Order of reaching val MSE < 0.05 (fastest first): " +
                     ", ".join(f"{r['optimizer']} ({r['epochs_to_threshold']} epochs)" for r in order) + ".")
    slow = [r["optimizer"] for r in rows if r["epochs_to_threshold"] is None]
    if slow:
        lines.append("Did not reach the threshold within the budget: " + ", ".join(slow) + ".")
    lowest = min(rows, key=lambda r: r["best_val_mse"])
    lines.append(f"Lowest validation MSE overall: {lowest['optimizer']} ({lowest['best_val_mse']:.5f}).")
    lines += ["", "## Why (to discuss in the report / viva)", "",
              "- **SGD** uses one global step size, so it must be small enough for the steepest direction and is then slow along flat ones.",
              "- **Momentum** accumulates a velocity, smoothing noisy mini-batch gradients and accelerating along consistent directions.",
              "- **RMSprop** divides by a running RMS of each parameter's gradient, giving every weight its own effective step size.",
              "- **Adam** combines momentum (first moment) with RMSprop-style scaling (second moment) plus bias correction, "
              "which usually makes it the least sensitive to the learning rate.",
              "- Always compare against the table above: if your run disagrees with this generic story, explain it with your own numbers."]
    (RESULTS / "convergence_comparison.md").write_text("\n".join(lines) + "\n")
    (RESULTS / "convergence_comparison.json").write_text(json.dumps(
        {"rows": rows, "dataset_source": data.source, "grid": {k: v["grid"] for k, v in best.items()}}, indent=2))

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    colors = {"sgd": "#6c757d", "momentum": "#2a9d8f", "rmsprop": "#e9a100", "adam": "#c1121f"}
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    for name, b in best.items():
        ax.plot(b["curve"], color=colors[name], label=f"{name} (lr={b['lr']:g})")
    ax.axhline(THRESHOLD, color="k", ls=":", lw=1)
    ax.set_yscale("log"); ax.set_xlabel("epoch"); ax.set_ylabel("validation MSE (standardised)")
    ax.set_title("Convergence speed on Energy Efficiency"); ax.legend(); fig.tight_layout()
    fig.savefig(RESULTS / "optimizer_convergence.png", dpi=140)
    print("\n" + "\n".join(lines[4 if not data.is_synthetic else 6:12]))


if __name__ == "__main__":
    main()
