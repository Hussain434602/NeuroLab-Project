"""Run the numerical gradient check and save a report.   python -m experiments.gradient_check"""
import json
from pathlib import Path

from neurolab.gradcheck import THRESHOLD, run_full_check

RESULTS = Path(__file__).resolve().parent.parent / "results"


def main():
    RESULTS.mkdir(exist_ok=True)
    rows = run_full_check()
    width = max(len(r["layer"]) for r in rows)
    for r in rows:
        print(f"{r['layer']:<{width}}  {r['param']:<10} {r['rel_error']:.2e}  {'PASS' if r['passed'] else 'FAIL'}")
    worst = max(r["rel_error"] for r in rows)
    ok = all(r["passed"] for r in rows)
    print(f"\nworst relative error {worst:.2e} (threshold {THRESHOLD:.0e}) -> {'PASS' if ok else 'FAIL'}")
    (RESULTS / "gradient_check.json").write_text(json.dumps({"threshold": THRESHOLD, "worst": worst, "passed": ok, "rows": rows}, indent=2))
    raise SystemExit(0 if ok else 1)


if __name__ == "__main__":
    main()
